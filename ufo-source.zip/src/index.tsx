import { definePlugin } from "@decky/api";
import { PanelSection, PanelSectionRow, ToggleField, SliderField } from "@decky/ui";
import { useState } from "react";
import { FaSpaceShuttle } from "react-icons/fa";

import { UfoInjector } from "./injector";

type Cfg = Record<string, number>;

// ── The locked preset, baked verbatim (tuned in the preview studio) ──────────
// Only count / calm / invaders are exposed in the menu; everything else is fixed.
const PRESET: Cfg = {
  count: 3, size: 1.5, ink: 55, link: 70, speed: 90, calm: 85, glow: 0, band: 70,
  invaders: 65, invSize: 210, ash: 80, lock: 90, patrol: 50, teleport: 40,
  fire: 10, grid: 60, gridScale: 220, crt: 50, blur: 100, hud: 70, stats: 0,
  statsX: 4, statsY: 8, badgeX: 64, badgeY: -28, badgeSize: 220, expX: 94, expY: 92,
  fps: 20,
};

interface Settings {
  enabled: boolean;
  pauseInGame: boolean;
  count: number;     // 1..4  UFOs
  calm: number;      // 0..100  calm <-> hyper
  invaders: number;  // 0..100  invader amount
}

const KEY = "ufo-bg.settings.v1";

const DEFAULTS: Settings = {
  enabled: true,
  pauseInGame: true,
  count: PRESET.count,
  calm: PRESET.calm,
  invaders: PRESET.invaders,
};

function load(): Settings {
  try { const raw = localStorage.getItem(KEY); if (raw) return { ...DEFAULTS, ...JSON.parse(raw) }; } catch { /* */ }
  return { ...DEFAULTS };
}
function save(s: Settings) { try { localStorage.setItem(KEY, JSON.stringify(s)); } catch { /* */ } }

function toConfig(s: Settings): Cfg {
  return { ...PRESET, count: s.count, calm: s.calm, invaders: s.invaders };
}

let settings = load();
let injector: UfoInjector;
try {
  injector = new UfoInjector(toConfig(settings), settings.pauseInGame);
  if (settings.enabled) injector.start();
} catch (e) {
  console.error("[UFO-BG] init failed", e);
  injector = injector! ?? new UfoInjector(toConfig(settings), settings.pauseInGame);
}

function apply(next: Partial<Settings>) {
  settings = { ...settings, ...next };
  save(settings);
  try {
    injector.setPauseInGame(settings.pauseInGame);
    injector.setConfig(toConfig(settings));
    if (settings.enabled) injector.start(); else injector.stop();
  } catch (e) { console.error("[UFO-BG] apply failed", e); }
}

function Content() {
  const [s, setS] = useState<Settings>(settings);
  const update = (p: Partial<Settings>) => { apply(p); setS({ ...settings }); };

  return (
    <PanelSection title="UFO Background">
      <PanelSectionRow>
        <ToggleField label="Enabled" checked={s.enabled} onChange={(v) => update({ enabled: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="UFOs" value={s.count} min={1} max={4} step={1} notchTicksVisible
          description="How many saucers in the fleet"
          onChange={(v) => update({ count: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Calm — Hyper" value={s.calm} min={0} max={100} step={5}
          description="Energy: low = slow & mellow, high = fast & frantic"
          onChange={(v) => update({ calm: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Invaders" value={s.invaders} min={0} max={100} step={5}
          description="How many targets spawn for the fleet to hunt"
          onChange={(v) => update({ invaders: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <ToggleField label="Pause while playing" checked={s.pauseInGame}
          description="Saves battery: freezes the animation when a game is running"
          onChange={(v) => update({ pauseInGame: v })} />
      </PanelSectionRow>
    </PanelSection>
  );
}

export default definePlugin(() => ({
  name: "UFO Background",
  titleView: <div>UFO Background</div>,
  alwaysRender: false,
  content: <Content />,
  icon: <FaSpaceShuttle />,
  onDismount() {
    try { injector.stop(); } catch (e) { console.error("[UFO-BG] onDismount failed", e); }
  },
}));
