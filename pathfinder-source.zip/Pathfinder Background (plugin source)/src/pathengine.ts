// @ts-nocheck
// pathengine.ts v1.2 — A* grid pathfinder. Verbatim port of astar-grid-preview.html.
// Patterns scatter/maze; themes Default/Matrix/Rainbow; pixelated "target ripple" at
// the target (on found) and source (on snake arrival). No SOURCE/TARGET labels.
// Fixed 1920x1080 coordinate space scaled to the mounted art layer; visible-window clock.

export function createPathEngine(canvas, rawCfg, win){
  const cv = canvas;
  const ctx = cv.getContext('2d', { alpha:false });
  const _doc = canvas.ownerDocument || document;
  const DEV_W = 1920, DEV_H = 1080;
  let W = DEV_W, H = DEV_H, DPR = 1;

  let CFG = { cadence:'calm', searchSpeed:0.3, density:3.0, obstacles:0.38,
              diag:true, glow:0.10, keepout:false, theme:0, pattern:'scatter', prize:true, fps:30 };
  function applyCfg(raw){
    if(!raw) return;
    if('cadence'    in raw) CFG.cadence     = (+raw.cadence===1)?'cont':'calm';
    if('searchSpeed'in raw) CFG.searchSpeed = (+raw.searchSpeed)/100;
    if('density'    in raw) CFG.density     = (+raw.density)/100;
    if('obstacles'  in raw) CFG.obstacles   = (+raw.obstacles)/100;
    if('diag'       in raw) CFG.diag        = !!+raw.diag;
    if('glow'       in raw) CFG.glow        = (+raw.glow)/100;
    if('keepout'    in raw) CFG.keepout     = !!+raw.keepout;
    if('pattern'    in raw) CFG.pattern     = (+raw.pattern===1)?'maze':'scatter';
    if('prize'      in raw) CFG.prize       = !!+raw.prize;
    if('theme'      in raw) CFG.theme       = (+raw.theme)|0;
    if('fps'        in raw) CFG.fps         = +raw.fps;
  }
  applyCfg(rawCfg);

  const THEMES = [
    {name:'Default', glow:'#23dcff', core:'#e9feff', dim:'#2c6f86', wall:'#0d2230', bg:'#070f1a', grid:'rgba(40,120,150,0.07)', trace:'#8eeeff'},
    {name:'Matrix',  glow:'#21ff5f', core:'#d6ffdc', dim:'#1c5a2e', wall:'#06160c', bg:'#010600', grid:'rgba(0,255,80,0.07)', trace:'#ffe000', route:'#ffe000'},
    {name:'Rainbow', glow:'#ffffff', core:'#ffffff', dim:'#9aa0aa', wall:'#e4e4ec', bg:'#ffffff', grid:'rgba(0,0,0,0)', trace:'#0b5cff', route:'#0b5cff', label:'#101014', rainbow:true, light:true}
  ];
  function hexA(hex,a){ const n=parseInt(hex.slice(1),16);
    return `rgba(${(n>>16)&255},${(n>>8)&255},${n&255},${a})`; }

  // ---------- grid ----------
  let cols=0,rows=0,cell=0,ox=0,oy=0,wall=null;
  const idx=(c,r)=>r*cols+c;
  const cx=c=>ox+c*cell+cell/2, cyf=r=>oy+r*cell+cell/2;
  function buildGrid(){
    const baseCell=Math.max(14, Math.min(46, Math.min(W,H)/24));
    cell=Math.max(9, baseCell/CFG.density);
    cols=Math.max(6,Math.floor(W/cell)); rows=Math.max(6,Math.floor(H/cell));
    ox=(W-cols*cell)/2; oy=(H-rows*cell)/2;
    const n=cols*rows; wall=new Uint8Array(n);
    if(CFG.pattern==='maze'){
      for(let i=0;i<n;i++) wall[i]=1;
      const inb=(c,r)=>c>=0&&r>=0&&c<cols&&r<rows;
      const st=[[0,0]]; wall[idx(0,0)]=0;
      const dirs=[[2,0],[-2,0],[0,2],[0,-2]];
      while(st.length){
        const [c,r]=st[st.length-1];
        const ds=dirs.slice().sort(()=>Math.random()-0.5); let moved=false;
        for(const [dc,dr] of ds){ const nc=c+dc,nr=r+dr;
          if(inb(nc,nr)&&wall[idx(nc,nr)]===1){ wall[idx(c+dc/2,r+dr/2)]=0; wall[idx(nc,nr)]=0; st.push([nc,nr]); moved=true; break; } }
        if(!moved) st.pop();
      }
      const nb=[[1,0],[-1,0],[0,1],[0,-1]];
      for(let r=1;r<rows-1;r++)for(let c=1;c<cols-1;c++){ if(wall[idx(c,r)]) continue;
        let open=0; for(const [dc,dr] of nb){ const cc=c+dc,rr=r+dr; if(inb(cc,rr)&&!wall[idx(cc,rr)]) open++; }
        if(open===1 && Math.random()<0.12){
          const cand=nb.map(([dc,dr])=>[c+dc,r+dr]).filter(([cc,rr])=>cc>0&&rr>0&&cc<cols-1&&rr<rows-1&&wall[idx(cc,rr)]);
          if(cand.length){ const [cc,rr]=cand[(Math.random()*cand.length)|0]; wall[idx(cc,rr)]=0; }
        }
      }
    } else {
      const fill = CFG.obstacles*0.92;
      for(let i=0;i<n;i++) wall[i]=Math.random()<fill?1:0;
      const nx=new Uint8Array(n);
      for(let r=0;r<rows;r++)for(let c=0;c<cols;c++){
        let w=0;
        for(let dr=-1;dr<=1;dr++)for(let dc=-1;dc<=1;dc++){
          if(!dr&&!dc)continue; const cc=c+dc,rr=r+dr;
          if(cc<0||rr<0||cc>=cols||rr>=rows){ w++; continue; }
          w+=wall[idx(cc,rr)];
        }
        nx[idx(c,r)] = (w<=1)?0:(w>=8?1:wall[idx(c,r)]);
      }
      wall=nx;
    }
    if(CFG.keepout){
      const r0=Math.floor(rows*0.40), r1=Math.floor(rows*0.60);
      const gap1=Math.floor(cols*0.30), gap2=Math.floor(cols*0.68);
      for(let r=r0;r<=r1;r++)for(let c=0;c<cols;c++){
        const open=(Math.abs(c-gap1)<=1)||(Math.abs(c-gap2)<=1);
        wall[idx(c,r)]= open?0:1;
      }
    }
  }

  // ---------- A* ----------
  let srcI=0,dstI=0;
  function passable(i){ return wall[i]===0; }
  function carveOpen(i){ wall[i]=0; }
  function neighbors(i){
    const c=i%cols, r=(i-c)/cols, out=[];
    const orth=[[1,0],[-1,0],[0,1],[0,-1]];
    for(const [dc,dr] of orth){ const cc=c+dc,rr=r+dr;
      if(cc>=0&&rr>=0&&cc<cols&&rr<rows&&passable(idx(cc,rr))) out.push([idx(cc,rr),1]); }
    if(CFG.diag){
      const dia=[[1,1],[1,-1],[-1,1],[-1,-1]];
      for(const [dc,dr] of dia){ const cc=c+dc,rr=r+dr;
        if(cc<0||rr<0||cc>=cols||rr>=rows) continue;
        if(!passable(idx(cc,rr))) continue;
        if(!passable(idx(c+dc,r))||!passable(idx(c,r+dr))) continue;
        out.push([idx(cc,rr),1.41421356]);
      }
    }
    return out;
  }
  function heur(a,b){
    const ac=a%cols,ar=(a-ac)/cols, bc=b%cols,br=(b-bc)/cols;
    const dx=Math.abs(ac-bc),dy=Math.abs(ar-br);
    const h = CFG.diag ? (dx+dy)+(1.41421356-2)*Math.min(dx,dy) : (dx+dy);
    return h*1.002;
  }
  function astar(s,t){
    const n=cols*rows;
    const g=new Float64Array(n).fill(Infinity);
    const f=new Float64Array(n).fill(Infinity);
    const came=new Int32Array(n).fill(-1);
    const closed=new Uint8Array(n), inOpen=new Uint8Array(n);
    const open=[]; const order=[];
    g[s]=0; f[s]=heur(s,t); open.push(s); inOpen[s]=1;
    while(open.length){
      let bi=0; for(let k=1;k<open.length;k++) if(f[open[k]]<f[open[bi]]) bi=k;
      const u=open[bi]; open[bi]=open[open.length-1]; open.pop(); inOpen[u]=0;
      if(closed[u]) continue;
      closed[u]=1; order.push(u);
      if(u===t) break;
      for(const [v,w] of neighbors(u)){
        if(closed[v]) continue;
        const ng=g[u]+w;
        if(ng<g[v]){ g[v]=ng; f[v]=ng+heur(v,t); came[v]=u;
          if(!inOpen[v]){ open.push(v); inOpen[v]=1; } }
      }
    }
    const path=[]; if(came[t]!==-1||s===t){ let c=t; while(c!==-1){ path.unshift(c); c=came[c]; } }
    return {order,came,path};
  }
  function pickEnds(){
    const pass=[];
    for(let i=0;i<wall.length;i++) if(passable(i)) pass.push(i);
    if(pass.length<2){ carveOpen(idx(1,1)); carveOpen(idx(cols-2,rows-2)); srcI=idx(1,1); dstI=idx(cols-2,rows-2); return; }
    const md=(a,b)=>{ const ac=a%cols,ar=(a-ac)/cols,bc=b%cols,br=(b-bc)/cols; return Math.abs(ac-bc)+Math.abs(ar-br); };
    const minD=(cols+rows)*0.55;
    let bestS=pass[0],bestT=pass[1],bestD=-1;
    for(let t=0;t<28;t++){
      const a=pass[(Math.random()*pass.length)|0], b=pass[(Math.random()*pass.length)|0];
      const d=md(a,b);
      if(d>=minD){ srcI=a; dstI=b; return; }
      if(d>bestD){ bestD=d; bestS=a; bestT=b; }
    }
    srcI=bestS; dstI=bestT;
  }

  // ---------- run state ----------
  let phase='search', t0=0, run={}, prizeStart=-1, prizeStartSrc=-1;
  function carveCorridor(s,t){
    let c=s%cols, r=(s-c)/cols; const tc=t%cols, tr=(t-(t%cols))/cols;
    let steps=0, max=cols*rows*2;
    while((c!==tc||r!==tr) && steps++<max){
      wall[idx(c,r)]=0;
      if(Math.random()<0.74){ if(Math.abs(tc-c)>Math.abs(tr-r)) c+=Math.sign(tc-c); else r+=Math.sign(tr-r); }
      else { if(Math.random()<0.5) c+=(Math.random()<0.5?1:-1); else r+=(Math.random()<0.5?1:-1); }
      c=Math.max(0,Math.min(cols-1,c)); r=Math.max(0,Math.min(rows-1,r));
    }
    wall[idx(tc,tr)]=0;
  }
  function resetRun(){
    pickEnds();
    run=astar(srcI,dstI);
    let tries=0;
    while(run.path.length<2 && tries<6){
      tries++;
      if(tries<=2){ pickEnds(); }
      else { carveOpen(srcI); carveOpen(dstI); carveCorridor(srcI,dstI); }
      run=astar(srcI,dstI);
    }
    run.k=run.order.length;
    phase='search'; t0=win.performance.now(); prizeStart=-1; prizeStartSrc=-1;
  }

  // ---------- draw ----------
  function background(){
    const P=THEMES[CFG.theme];
    ctx.fillStyle=P.bg; ctx.fillRect(0,0,W,H);
    ctx.lineWidth=1; ctx.strokeStyle=P.grid;
    ctx.beginPath();
    for(let c=0;c<=cols;c++){ const x=ox+c*cell; ctx.moveTo(x,oy); ctx.lineTo(x,oy+rows*cell); }
    for(let r=0;r<=rows;r++){ const y=oy+r*cell; ctx.moveTo(ox,y); ctx.lineTo(ox+cols*cell,y); }
    ctx.stroke();
    const g=ctx.createRadialGradient(W/2,H/2,Math.min(W,H)*0.2,W/2,H/2,Math.max(W,H)*0.72);
    g.addColorStop(0,'rgba(0,0,0,0)'); g.addColorStop(1, P.light?'rgba(255,255,255,0)':'rgba(2,6,12,0.85)');
    ctx.fillStyle=g; ctx.fillRect(0,0,W,H);
  }
  function fillCell(i,style){ const c=i%cols,r=(i-c)/cols;
    ctx.fillStyle=style; ctx.fillRect(ox+c*cell+0.5,oy+r*cell+0.5,cell-1,cell-1); }
  function drawBlock(i,a,bright){
    const P=THEMES[CFG.theme], c=i%cols, r=(i-c)/cols, x=ox+c*cell, y=oy+r*cell, sgn=cell;
    const pad=Math.max(0.3,sgn*0.04), rad=Math.max(1,sgn*0.18);
    ctx.beginPath(); ctx.roundRect(x+pad,y+pad,sgn-2*pad,sgn-2*pad,rad);
    ctx.fillStyle=hexA(P.route||'#ffffff', a); ctx.fill();
  }
  function durs(){ const calm=CFG.cadence==='calm', sp=CFG.searchSpeed;
    return { search:(calm?1700:900)/sp, hold:(calm?3200:900), fade:(calm?900:380), gap:(calm?500:120) }; }

  // ---------- frame ----------
  let raf=0, running=false, lastDraw=0;
  function frame(now){
    if(!running) return;
    raf=win.requestAnimationFrame(frame);
    const cap=CFG.fps>0?CFG.fps:30;
    if(now-lastDraw < (1000/cap)-1) return;
    lastDraw=now;

    const P=THEMES[CFG.theme], D=durs(), el=now-t0;
    background();

    for(let i=0;i<wall.length;i++) if(wall[i]) fillCell(i,P.wall);

    let k=run.k;
    if(phase==='search') k=Math.min(run.k, Math.floor(run.k*(el/D.search)));
    let resultA=1;
    if(phase==='fade') resultA=Math.max(0,1-(el/D.fade));
    else if(phase==='gap') resultA=0;

    for(let q=0;q<k;q++){ const i=run.order[q]; const t=q/Math.max(1,k);
      if(P.rainbow){ const hue=(t*330)|0, a=Math.min(0.96,0.55+0.4*t)*resultA;
        fillCell(i, 'hsla('+hue+',100%,50%,'+a.toFixed(3)+')'); }
      else { const a=(0.06+0.20*t)*resultA; fillCell(i, hexA(P.glow,a)); }
    }
    const fr=Math.max(1,Math.floor(run.k*0.05));
    for(let q=Math.max(0,k-fr);q<k;q++){ const i=run.order[q],c=i%cols,r=(i-c)/cols;
      ctx.strokeStyle=hexA(P.core,0.6*resultA); ctx.lineWidth=1.2;
      ctx.strokeRect(ox+c*cell+1,oy+r*cell+1,cell-2,cell-2);
    }

    fillCell(srcI, hexA(P.core,0.85*resultA)); fillCell(dstI, hexA(P.glow,0.85*resultA));

    function crawlDur(n){ return Math.min(D.hold*0.8, Math.max(600, n*(CFG.cadence==='calm'?70:35))); }
    if(phase!=='search' && phase!=='gap' && run.path.length>1){
      const cells=run.path; const L=cells.length;
      ctx.save(); ctx.globalCompositeOperation='source-over'; ctx.lineJoin='round';
      if(phase==='strike'){
        const segLen=Math.max(4, Math.min(16, Math.round(L*0.28)));
        const p=Math.min(1, el/crawlDur(L)), headIdx=Math.round((L-1)*(1-p));
        const visible=cells.slice(headIdx, Math.min(L-1, headIdx+segLen-1)+1);
        for(let q=0;q<visible.length;q++){ const taper=1-(q/Math.max(1,visible.length))*0.72; drawBlock(visible[q], taper, q===0); }
      } else {
        for(let i=0;i<L;i++){ const grad=1-(i/Math.max(1,L-1))*0.9; drawBlock(cells[i], grad*resultA, false); }
      }
      ctx.restore();
    }

    // ---- TARGET RIPPLE — pixelated wave at the target (found) and source (arrival) ----
    if(CFG.prize){
      const ripple=(centerI, st, dur)=>{ if(st<0) return; const pe=now-st; if(pe>=dur) return;
        const col=P.route||P.core||'#ffffff';
        const dc0=centerI%cols, dr0=(centerI-(centerI%cols))/cols;
        const maxRc=Math.max(3,(Math.min(W,H)*0.085)/cell);
        const rt=pe/dur, R=rt*maxRc, a=(1-rt)*0.8;
        ctx.save(); ctx.globalCompositeOperation = P.light?'source-over':'lighter';
        const Lr=Math.ceil(R)+1;
        for(let dc=-Lr;dc<=Lr;dc++)for(let dr=-Lr;dr<=Lr;dr++){
          const cc=dc0+dc, rr=dr0+dr; if(cc<0||rr<0||cc>=cols||rr>=rows) continue;
          const d=Math.sqrt(dc*dc+dr*dr);
          if(Math.abs(d-R)<=0.9) fillCell(idx(cc,rr), hexA(col,a));
        }
        if(pe<500) fillCell(centerI, hexA(col,0.7*(1-pe/500)));
        ctx.restore();
      };
      ripple(dstI, prizeStart, 1560);     // target — when A* found it
      ripple(srcI, prizeStartSrc, 1040);  // source — when snake arrives (faster)
    }

    // status (no SOURCE/TARGET labels)
    ctx.save(); ctx.globalAlpha=resultA; const LBL=P.label||P.glow;
    ctx.font='12px ui-monospace,monospace';
    if(phase==='search'){ ctx.fillStyle=hexA(LBL,0.6);
      ctx.fillText('A* — '+k+'/'+run.k+' cells explored', 16, H-22); }
    else if(phase==='strike'||phase==='lock'){ ctx.fillStyle=hexA(LBL,0.9);
      const crawling = phase==='strike' && el < crawlDur(run.path.length);
      ctx.fillText(crawling?'CRAWLING ROUTE…':'ROUTE LOCKED  ('+(run.path.length-1)+' steps)', 16, H-22); }
    ctx.restore();

    if(phase==='search'&&el>=D.search){ phase='strike'; t0=now; prizeStart=now; }
    else if(phase==='strike'&&el>=crawlDur(run.path.length)){ phase='lock'; t0=now; prizeStartSrc=now; }
    else if(phase==='lock'&&el>=D.hold){ phase='fade'; t0=now; }
    else if(phase==='fade'&&el>=D.fade){ phase='gap'; t0=now; }
    else if(phase==='gap'&&el>=D.gap){ buildGrid(); resetRun(); }
  }

  function resize(){
    DPR=Math.min(2, win.devicePixelRatio||1);
    const r=cv.getBoundingClientRect(); const cw=Math.max(2,r.width), ch=Math.max(2,r.height);
    cv.width=Math.round(cw*DPR); cv.height=Math.round(ch*DPR);
    W=DEV_W; H=DEV_H;
    ctx.setTransform(cv.width/DEV_W, 0, 0, cv.height/DEV_H, 0, 0);
    ctx.imageSmoothingEnabled=true;
  }
  function start(){ if(running) return; running=true; resize(); if(!wall){ buildGrid(); resetRun(); } lastDraw=0; raf=win.requestAnimationFrame(frame); }
  function stop(){ running=false; if(raf){ try{ win.cancelAnimationFrame(raf); }catch(e){} } raf=0; }
  function setConfig(raw){
    const reb = raw && (('density' in raw)||('obstacles' in raw)||('pattern' in raw)||('keepout' in raw)||('diag' in raw));
    applyCfg(raw);
    if(reb){ buildGrid(); resetRun(); }
  }
  function setStats(){ /* none */ }

  return { start, stop, setConfig, setStats, resize };
}
