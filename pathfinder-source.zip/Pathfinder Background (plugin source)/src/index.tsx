import { definePlugin } from "@decky/api";
import { PanelSection, PanelSectionRow, ToggleField, SliderField, DropdownItem } from "@decky/ui";
import { useState } from "react";
import { FaRoute } from "react-icons/fa";

import { PathInjector } from "./injector";

type Cfg = Record<string, number>;

interface Profile {
  cadence: number; searchSpeed: number; density: number; obstacles: number;
  diag: number; keepout: number; pattern: number;
}

// ── Baked from sea's exported preset (all themes identical: scatter / density 300 / search 0.3 / 8-dir) ──
const PROFILES_DEFAULT: Profile[] = [
  { cadence: 0, searchSpeed: 30, density: 300, obstacles: 38, diag: 1, keepout: 0, pattern: 0 },
  { cadence: 0, searchSpeed: 30, density: 300, obstacles: 38, diag: 1, keepout: 0, pattern: 0 },
  { cadence: 0, searchSpeed: 30, density: 300, obstacles: 38, diag: 1, keepout: 0, pattern: 0 },
];
const THEME_LABELS = [
  { data: 0, label: "Default (cyan)" },
  { data: 1, label: "Matrix (green)" },
  { data: 2, label: "Rainbow (white)" },
];
const FIXED = { glow: 10, fps: 30 };

interface Settings {
  enabled: boolean;
  pauseInGame: boolean;
  ripple: boolean;        // target ripple
  theme: number;
  profiles: Profile[];
}

const KEY = "pathfinder-bg.settings.v3";   // schema/defaults changed

const DEFAULTS: Settings = {
  enabled: true,
  pauseInGame: true,
  ripple: true,
  theme: 0,
  profiles: PROFILES_DEFAULT.map((p) => ({ ...p })),
};

function load(): Settings {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const s = JSON.parse(raw);
      const out: Settings = { ...DEFAULTS, ...s };
      out.profiles = PROFILES_DEFAULT.map((d, i) => ({ ...d, ...(s.profiles?.[i] || {}) }));
      return out;
    }
  } catch { /* */ }
  return { ...DEFAULTS, profiles: PROFILES_DEFAULT.map((p) => ({ ...p })) };
}
function save(s: Settings) { try { localStorage.setItem(KEY, JSON.stringify(s)); } catch { /* */ } }

function toConfig(s: Settings): Cfg {
  const p = s.profiles[s.theme] || PROFILES_DEFAULT[s.theme];
  return {
    theme: s.theme,
    cadence: p.cadence, searchSpeed: p.searchSpeed, density: p.density,
    obstacles: p.obstacles, diag: p.diag, keepout: p.keepout, pattern: p.pattern,
    prize: s.ripple ? 1 : 0,
    glow: FIXED.glow, fps: FIXED.fps,
  };
}

let settings = load();
let injector: PathInjector;
try {
  injector = new PathInjector(toConfig(settings), settings.pauseInGame);
  if (settings.enabled) injector.start();
} catch (e) {
  console.error("[PATH-BG] init failed", e);
  injector = injector! ?? new PathInjector(toConfig(settings), settings.pauseInGame);
}

function pushConfig() {
  save(settings);
  try {
    injector.setPauseInGame(settings.pauseInGame);
    injector.setConfig(toConfig(settings));
    if (settings.enabled) injector.start(); else injector.stop();
  } catch (e) { console.error("[PATH-BG] apply failed", e); }
}

function Content() {
  const [, force] = useState(0);
  const rerender = () => force((x) => x + 1);
  const t = settings.theme;
  const p = settings.profiles[t];

  const setProfile = (patch: Partial<Profile>) => {
    settings.profiles[t] = { ...settings.profiles[t], ...patch };
    pushConfig(); rerender();
  };
  const setTop = (patch: Partial<Settings>) => {
    settings = { ...settings, ...patch };
    pushConfig(); rerender();
  };

  return (
    <PanelSection title="Pathfinder Background">
      <PanelSectionRow>
        <ToggleField label="Enabled" checked={settings.enabled} onChange={(v) => setTop({ enabled: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <DropdownItem label="Theme" rgOptions={THEME_LABELS}
          selectedOption={t} onChange={(o) => setTop({ theme: o.data as number })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <DropdownItem label="Moves" rgOptions={[
            { data: 1, label: "8-dir (diagonal)" },
            { data: 0, label: "4-dir (orthogonal)" },
          ]} selectedOption={p.diag} onChange={(o) => setProfile({ diag: o.data as number })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <ToggleField label="Target ripple" checked={settings.ripple}
          description="Pixelated ripple out of the target when found, and the source on arrival"
          onChange={(v) => setTop({ ripple: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Search speed" value={p.searchSpeed} min={30} max={360} step={10}
          description="How fast A* explores (lower = slower, more deliberate)"
          onChange={(v) => setProfile({ searchSpeed: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Density" value={p.density} min={60} max={300} step={10}
          description="Grid resolution. Higher = finer grid (heavier on battery)"
          onChange={(v) => setProfile({ density: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <ToggleField label="Pause while playing" checked={settings.pauseInGame}
          description="Saves battery: freezes the animation when a game is running"
          onChange={(v) => setTop({ pauseInGame: v })} />
      </PanelSectionRow>
    </PanelSection>
  );
}

export default definePlugin(() => ({
  name: "Pathfinder Background",
  titleView: <div>Pathfinder Background</div>,
  alwaysRender: false,
  content: <Content />,
  icon: <FaRoute />,
  onDismount() {
    try { injector.stop(); } catch (e) { console.error("[PATH-BG] onDismount failed", e); }
  },
}));
