# Floor796 Wallpaper — backend.
# Serves the user's OWN local floor796.html over a localhost HTTP server so the
# Steam UI (CEF) can mount it in an iframe. The floor796 file is NOT shipped with
# this plugin; the user supplies their own copy (local viewing, per the author).
import os, glob, json, threading, http.server, socketserver, urllib.parse

PORTS = list(range(8796, 8816))            # try a small range until one binds
FNAME_HINTS = ["floor796.html"]            # exact preferred name
GLOB_HINTS  = ["floor796*.html", "*floor796*.html"]

def _home():
    return os.environ.get("DECKY_USER_HOME") or os.environ.get("HOME") or os.path.expanduser("~")

def _data_dir():
    # Recommended drop folder for the big file; created if missing.
    d = os.environ.get("DECKY_PLUGIN_RUNTIME_DIR") \
        or os.environ.get("DECKY_PLUGIN_SETTINGS_DIR") \
        or os.path.join(_home(), ".local", "share", "floor796-wallpaper")
    try: os.makedirs(d, exist_ok=True)
    except Exception: pass
    return d

def _search_dirs():
    h = _home()
    dirs = [
        _data_dir(),
        os.environ.get("DECKY_PLUGIN_DIR", ""),
        os.path.join(os.environ.get("DECKY_PLUGIN_DIR", ""), "assets"),
        h,
        os.path.join(h, "Downloads"),
        os.path.join(h, "Desktop"),
        os.path.join(h, "Documents"),
        "/home/deck", "/home/deck/Downloads",
    ]
    return [d for d in dirs if d and os.path.isdir(d)]

def find_file(user_path=""):
    if user_path and os.path.isfile(user_path):
        return user_path
    for d in _search_dirs():
        for n in FNAME_HINTS:
            p = os.path.join(d, n)
            if os.path.isfile(p):
                return p
    for d in _search_dirs():
        for pat in GLOB_HINTS:
            hits = sorted(glob.glob(os.path.join(d, pat)))
            if hits:
                return hits[0]
    return ""

# shared mutable state the handler reads each request
STATE = {"user_path": "", "found": "", "port": 0}

def _fallback_html(data_dir, found):
    # Tiny self-test page (mine) — proves the server + iframe render in Steam's CEF
    # and tells the user exactly where to put the big file.
    return ("""<!doctype html><html><head><meta charset="utf-8">
<style>
 html,body{margin:0;height:100%;background:#0b0f1a;overflow:hidden;
   font-family:system-ui,Segoe UI,Roboto,sans-serif;color:#e7ecf5}
 .wrap{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:6vw}
 h1{font-size:4.4vw;margin:0 0 2vh;color:#7fd0c0}
 p{font-size:2.4vw;line-height:1.5;max-width:80%;color:#cdd6e8}
 code{background:#16203a;padding:.2em .5em;border-radius:.4em;color:#ffd479;font-size:2.2vw;word-break:break-all}
 .dot{width:14px;height:14px;border-radius:50%;background:#39c0b0;display:inline-block;margin-right:10px;animation:b 1.2s infinite}
 @keyframes b{0%,100%{opacity:.25}50%{opacity:1}}
</style></head><body><div class="wrap">
 <h1><span class="dot"></span>Floor796 Wallpaper is working</h1>
 <p>The local server and the on-screen iframe are rendering. Now copy your
 <b>floor796.html</b> file into this folder on the device, then press
 <b>Reload wallpaper</b> in the Quick Access menu:</p>
 <p><code>%DIR%</code></p>
 <p style="opacity:.7;font-size:1.9vw">(Any file named floor796.html in your Home or Downloads folder is found automatically too.)</p>
</div></body></html>""").replace("%DIR%", data_dir)

class Handler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def log_message(self, *a): pass   # silence

    def _serve_fallback(self):
        body = _fallback_html(_data_dir(), STATE["found"]).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _serve_file(self, path):
        try:
            size = os.path.getsize(path)
        except Exception:
            return self._serve_fallback()
        rng = self.headers.get("Range")
        start, end = 0, size - 1
        partial = False
        if rng and rng.startswith("bytes="):
            try:
                s, e = rng[6:].split("-", 1)
                if s.strip() != "": start = int(s)
                if e.strip() != "": end = int(e)
                end = min(end, size - 1)
                if start <= end: partial = True
            except Exception:
                partial = False
        length = (end - start + 1) if partial else size
        self.send_response(206 if partial else 200)
        self.send_header("Content-Type", "text/html; charset=windows-1251")
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(length))
        if partial:
            self.send_header("Content-Range", "bytes %d-%d/%d" % (start, end, size))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        if self.command == "HEAD":
            return
        try:
            with open(path, "rb") as f:
                f.seek(start)
                remaining = length
                while remaining > 0:
                    chunk = f.read(min(262144, remaining))
                    if not chunk: break
                    self.wfile.write(chunk)
                    remaining -= len(chunk)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception:
            pass

    def do_HEAD(self): self.do_GET()
    def do_GET(self):
        p = find_file(STATE["user_path"])
        STATE["found"] = p
        if p:
            self._serve_file(p)
        else:
            self._serve_fallback()

class Server(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

def _start_server():
    for port in PORTS:
        try:
            httpd = Server(("127.0.0.1", port), Handler)
            STATE["port"] = port
            threading.Thread(target=httpd.serve_forever, name="floor796-http", daemon=True).start()
            return port
        except OSError:
            continue
    return 0

class Plugin:
    async def _main(self):
        if not STATE["port"]:
            _start_server()

    async def _unload(self):
        pass

    async def get_status(self):
        p = find_file(STATE["user_path"])
        STATE["found"] = p
        port = STATE["port"] or 0
        return {
            "ready": bool(port),
            "found": bool(p),
            "path": p or "",
            "size": (os.path.getsize(p) if p else 0),
            "port": port,
            "url": ("http://127.0.0.1:%d/floor796.html" % port) if port else "",
            "dataDir": _home(),
        }

    async def set_path(self, path: str):
        STATE["user_path"] = path or ""
        return await self.get_status()
