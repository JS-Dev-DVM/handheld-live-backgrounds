// sheeppasture.ts — framework-free canvas engine. An opaque top-down pixel
// pasture: a flock of original pixel sheep wander and graze over a procedurally
// drawn grass field (cached offscreen so only the flock repaints each frame).
// Same (canvas, cfg, win) interface as the Matrix/Wavescape engines so it drops
// straight into the proven injector. Performance: capped DPR (<=2), fps cap,
// static background built ONCE into an offscreen canvas, no shadowBlur.

export interface SheepConfig {
  flock: number;     // number of sheep (1..20)
  size: number;      // sheep pixel scale (2..8)
  speed: number;     // walk speed px/s (8..90)
  calm: number;      // 0..100 — higher = more grazing, longer stands
  scenery: number;   // 0..100 — density of trees/rocks/tufts
  grassHue: number;  // -40..60 hue shift of greens
  wool: string;      // hex wool color
  fps: number;       // frame cap (20..60)
  pauseInGame: boolean;
}

export const DEFAULT_CONFIG: SheepConfig = {
  flock: 8, size: 4, speed: 32, calm: 60, scenery: 55, grassHue: 0,
  wool: "#f1ede0", fps: 30, pauseInGame: true,
};

// ----- original pixel sheep (20x14), 3 frames -----
const SHEEP: { [k: string]: string[] } = {
  base: ["....................","..OOOOOOOOOOOO......",".OWWWWWWWWWWWWO.....",".OWWWWWWWWWWWWO.....",".OWWWWWwWWWWWWFFF...",".OWWWWwwwWWwWFFeFF..","OWWWWwWwWwwwwFFFFFF.",".OWWwwwWwwwwWFFFFFF.",".OWWWwWWWwWWWWFFFFF.","..OOWWWWWWWWWO......","....OOWWWWWOO.......","...L..OLOOOL..L.....","...L...L...L..L.....","...L...L...L..L....."],
  walk: ["....................","..OOOOOOOOOOOO......",".OWWWWWWWWWWWWO.....",".OWWWWWWWWWWWWO.....",".OWWWWWwWWWWWWFFF...",".OWWWWwwwWWwWFFeFF..","OWWWWwWwWwwwwFFFFFF.",".OWWwwwWwwwwWFFFFFF.",".OWWWwWWWwWWWWFFFFF.","..OOWWWWWWWWWO......","....OOWWWWWOO.......","....L.LOOOO.LL......","....L.L.....LL......","....L.L.....LL......"],
  eat:  ["....................","..OOOOOOOOOOOO......",".OWWWWWWWWWWWWO.....",".OWWWWWWWWWWWWO.....",".OWWWWWwWWWWWWWO....",".OWWWWwwwWWwWWWO....","OWWWWwWwWwwwwWFFF...",".OWWwwwWwwwwWFFeFF..",".OWWWwWWWwWWWFFFFFF.","..OOWWWWWWWWWFFFFFF.","....OOWWWWWOO.FFFFF.","...L..OLOOOL..L.....","...L...L...L..L.....","...L...L...L..L....."],
};
const SW = 20, SH = 14;

// ----- color helpers -----
function hex2rgb(h: string): [number, number, number] { const s = (h || "#ffffff").replace("#", ""); return [parseInt(s.slice(0,2),16), parseInt(s.slice(2,4),16), parseInt(s.slice(4,6),16)]; }
function rgb2hex(r: number, g: number, b: number): string { const c = (v: number) => ("0" + Math.max(0, Math.min(255, Math.round(v))).toString(16)).slice(-2); return "#" + c(r) + c(g) + c(b); }
function rgb2hsl(r: number, g: number, b: number): [number, number, number] { r/=255; g/=255; b/=255; const mx=Math.max(r,g,b), mn=Math.min(r,g,b); let h=0, s=0; const l=(mx+mn)/2; if(mx!==mn){ const d=mx-mn; s=l>.5?d/(2-mx-mn):d/(mx+mn); switch(mx){ case r: h=(g-b)/d+(g<b?6:0); break; case g: h=(b-r)/d+2; break; default: h=(r-g)/d+4; } h/=6; } return [h*360, s, l]; }
function hsl2rgb(h: number, s: number, l: number): [number, number, number] { h/=360; let r: number, g: number, b: number; if(s===0){ r=g=b=l; } else { const f=(p: number,q: number,t: number)=>{ if(t<0)t+=1; if(t>1)t-=1; if(t<1/6)return p+(q-p)*6*t; if(t<1/2)return q; if(t<2/3)return p+(q-p)*(2/3-t)*6; return p; }; const q=l<.5?l*(1+s):l+s-l*s, p=2*l-q; r=f(p,q,h+1/3); g=f(p,q,h); b=f(p,q,h-1/3); } return [r*255, g*255, b*255]; }
function shiftHue(hx: string, deg: number): string { if(!deg) return hx; const [r,g,b]=hex2rgb(hx); let [h,s,l]=rgb2hsl(r,g,b); h=(h+deg+360)%360; const [R,G,B]=hsl2rgb(h,s,l); return rgb2hex(R,G,B); }
function scaleL(hx: string, f: number): string { const [r,g,b]=hex2rgb(hx); let [h,s,l]=rgb2hsl(r,g,b); l=Math.max(0,Math.min(1,l*f)); const [R,G,B]=hsl2rgb(h,s,l); return rgb2hex(R,G,B); }
function woolPal(cfg: SheepConfig): { [k: string]: string | null } { const W=cfg.wool; return { ".": null, "W": W, "w": scaleL(W,.87), "O": scaleL(W,.66), "F": "#242424", "e": "#ffffff", "L": "#1b1b1b" }; }

function mulberry32(a: number) { return function() { a|=0; a=a+0x6D2B79F5|0; let t=Math.imul(a^a>>>15,1|a); t=t+Math.imul(t^t>>>7,61|t)^t; return ((t^t>>>14)>>>0)/4294967296; }; }

// ----- one sheep -----
class Sheep {
  x: number; y: number; tx: number; ty: number;
  state: string = "graze"; timer: number; dir = 1; walkPhase = 0; phase: number;
  constructor(W: number, H: number) {
    this.x = 0.15*W + Math.random()*0.7*W; this.y = 0.2*H + Math.random()*0.7*H;
    this.tx = this.x; this.ty = this.y; this.timer = 1 + Math.random()*3;
    this.dir = Math.random()<.5?1:-1; this.phase = Math.random()*6.28;
  }
  pick(W: number, H: number) { const m=40; this.tx = m + Math.random()*(W-2*m); this.ty = H*0.16 + Math.random()*(H-m-H*0.16); }
  step(dt: number, cfg: SheepConfig, W: number, H: number) {
    this.phase += dt; const calm = cfg.calm/100;
    if (this.state === "walk") {
      const dx=this.tx-this.x, dy=this.ty-this.y, d=Math.hypot(dx,dy);
      if (Math.abs(dx) > 1) this.dir = dx>0?1:-1;
      if (d < 2) { if (Math.random() < 0.45+calm*0.5) { this.state="graze"; this.timer = 2+Math.random()*3 + calm*5; } else { this.state="idle"; this.timer = 0.6+Math.random()*1.0; } }
      else { const v=cfg.speed*dt, k=Math.min(1,v/d); this.x+=dx*k; this.y+=dy*k; this.walkPhase+=v; }
    } else if (this.state === "graze") {
      this.timer -= dt; if (this.timer<=0) { if (Math.random()<0.2) { this.state="idle"; this.timer=0.5+Math.random()*0.7; } else { this.pick(W,H); this.state="walk"; } }
    } else {
      this.timer -= dt; if (this.timer<=0) { if (Math.random()<calm*0.5) { this.state="graze"; this.timer=2+Math.random()*3+calm*4; } else { this.pick(W,H); this.state="walk"; } }
    }
  }
}

export class SheepPasture {
  private ctx: CanvasRenderingContext2D;
  private cfg: SheepConfig;
  private W = 0; private H = 0; private dpr = 1;
  private raf = 0; private last = 0; private running = false;
  private flock: Sheep[] = [];
  private bg: HTMLCanvasElement | null = null; private bgSig = "";
  private win: Window = (typeof window !== "undefined" ? window : (globalThis as any));

  constructor(private canvas: HTMLCanvasElement, cfg: SheepConfig, win?: Window) {
    this.cfg = { ...cfg }; if (win) this.win = win;
    const c = canvas.getContext("2d", { alpha: false });
    if (!c) throw new Error("2d context unavailable");
    this.ctx = c; this.ctx.imageSmoothingEnabled = false;
  }

  setConfig(p: Partial<SheepConfig>) {
    const sceneryChanged = (p.scenery !== undefined && p.scenery !== this.cfg.scenery) || (p.grassHue !== undefined && p.grassHue !== this.cfg.grassHue);
    Object.assign(this.cfg, p);
    if (sceneryChanged) this.buildBG();
  }

  resize() {
    const r = this.canvas.getBoundingClientRect();
    this.W = Math.max(1, Math.floor(r.width || this.canvas.clientWidth || 1280));
    this.H = Math.max(1, Math.floor(r.height || this.canvas.clientHeight || 800));
    this.dpr = Math.min(this.win.devicePixelRatio || 1, 2);
    this.canvas.width = Math.floor(this.W * this.dpr);
    this.canvas.height = Math.floor(this.H * this.dpr);
    this.ctx.imageSmoothingEnabled = false;
    this.bgSig = ""; this.buildBG();
  }

  private buildBG() {
    if (this.W < 2 || this.H < 2) return;
    const sig = this.W + "x" + this.H + "|" + this.cfg.scenery + "|" + this.cfg.grassHue + "|" + this.dpr;
    if (sig === this.bgSig && this.bg) return; this.bgSig = sig;
    const d = this.canvas.ownerDocument || document;
    const bg = d.createElement("canvas"); bg.width = Math.floor(this.W*this.dpr); bg.height = Math.floor(this.H*this.dpr);
    const g = bg.getContext("2d"); if (!g) return; g.setTransform(this.dpr,0,0,this.dpr,0,0); g.imageSmoothingEnabled = false;
    const W = this.W, H = this.H, hue = this.cfg.grassHue;
    const g1 = shiftHue("#6f9e54", hue), g2 = shiftHue("#669350", hue), tuftD = shiftHue("#588545", hue), tuftL = shiftHue("#8cb86c", hue);
    g.fillStyle = g1; g.fillRect(0,0,W,H);
    const lg = g.createLinearGradient(0,0,0,H); lg.addColorStop(0,"rgba(255,255,240,0.07)"); lg.addColorStop(1,"rgba(0,0,0,0.10)"); g.fillStyle = lg; g.fillRect(0,0,W,H);
    const T = 18; g.fillStyle = g2; for (let y=0;y<H;y+=T) for (let x=0;x<W;x+=T) if (((x/T|0)+(y/T|0))%2) g.fillRect(x,y,T,T);
    const rng = mulberry32(1337);
    const nTuft = Math.round(40 + this.cfg.scenery/100*150);
    for (let i=0;i<nTuft;i++){ const x=rng()*W, y=rng()*H, c=rng()<.5?tuftD:tuftL; g.fillStyle=c; g.fillRect(x,y,2,2); g.fillRect(x-2,y+1,2,2); g.fillRect(x+2,y+1,2,2); }
    type Obj = { t: string; x: number; y: number; s: number };
    const objs: Obj[] = [];
    const nRock = Math.round(1 + this.cfg.scenery/100*4), nBush = Math.round(2 + this.cfg.scenery/100*6), nTree = Math.round(2 + this.cfg.scenery/100*8);
    for (let i=0;i<nRock;i++) objs.push({t:"rock",x:rng()*W,y:rng()*(H-40)+20,s:6+rng()*6});
    for (let i=0;i<nBush;i++) objs.push({t:"bush",x:rng()*W,y:rng()*(H-40)+20,s:7+rng()*6});
    for (let i=0;i<nTree;i++) objs.push({t:"tree",x:20+rng()*(W-40),y:30+rng()*(H-50),s:14+rng()*12});
    objs.sort((a,b)=>a.y-b.y);
    const foD = shiftHue("#3f7a3a",hue), foL = shiftHue("#4f9446",hue);
    for (const o of objs) {
      g.fillStyle = "rgba(0,0,0,0.18)"; g.beginPath(); g.ellipse(o.x,o.y,o.s*0.8,o.s*0.32,0,0,6.2832); g.fill();
      if (o.t === "rock") { g.fillStyle="#8b9197"; g.beginPath(); g.ellipse(o.x,o.y-o.s*0.4,o.s,o.s*0.7,0,0,6.2832); g.fill(); g.fillStyle="#c2c7cc"; g.beginPath(); g.ellipse(o.x-o.s*0.25,o.y-o.s*0.6,o.s*0.4,o.s*0.28,0,0,6.2832); g.fill(); }
      else if (o.t === "bush") { g.fillStyle=foD; g.beginPath(); g.ellipse(o.x,o.y-o.s*0.4,o.s,o.s*0.6,0,0,6.2832); g.fill(); g.fillStyle=foL; g.beginPath(); g.ellipse(o.x-o.s*0.2,o.y-o.s*0.6,o.s*0.5,o.s*0.35,0,0,6.2832); g.fill(); }
      else { const tw=o.s*0.9; g.fillStyle="#5b3f28"; g.fillRect(o.x-tw*0.12,o.y-o.s*0.9,tw*0.24,o.s*0.9); for (let k=0;k<3;k++){ const ly=o.y-o.s*0.8-k*o.s*0.7, wts=tw*(1.1-k*0.28); g.fillStyle=k%2?foL:foD; g.beginPath(); g.moveTo(o.x,ly-o.s*1.05); g.lineTo(o.x-wts,ly); g.lineTo(o.x+wts,ly); g.closePath(); g.fill(); } g.fillStyle=foL; g.beginPath(); g.moveTo(o.x,o.y-o.s*2.9); g.lineTo(o.x-tw*0.5,o.y-o.s*2.3); g.lineTo(o.x+tw*0.5,o.y-o.s*2.3); g.closePath(); g.fill(); }
    }
    this.bg = bg;
  }

  private ensureFlock() { const n = this.cfg.flock|0; while (this.flock.length<n) this.flock.push(new Sheep(this.W,this.H)); if (this.flock.length>n) this.flock.length=n; }

  private drawSheep(b: Sheep, pal: { [k: string]: string | null }) {
    const ctx = this.ctx, s = this.cfg.size; let grid: string[], bob = 0;
    if (b.state === "walk") { grid = (Math.floor(b.walkPhase/7)%2===0)?SHEEP.base:SHEEP.walk; bob = -Math.abs(Math.sin(b.walkPhase*0.06))*s*0.8; }
    else if (b.state === "graze") { grid = (Math.sin(b.phase*3)>0)?SHEEP.eat:SHEEP.base; }
    else { grid = SHEEP.base; bob = Math.sin(b.phase*1.6)*s*0.3; }
    const flip = b.dir < 0;
    const cx = b.x, footY = b.y, topY = footY - SH*s + bob, leftX = cx - SW*s/2;
    ctx.save(); ctx.globalAlpha = 0.22; ctx.fillStyle = "#000"; ctx.beginPath(); ctx.ellipse(cx, footY-s*1.2, SW*s*0.34, s*1.4, 0, 0, 6.2832); ctx.fill(); ctx.restore();
    const px = Math.ceil(s);
    for (let y=0;y<SH;y++){ const row = grid[y]; for (let x=0;x<SW;x++){ const ch = row[flip?(SW-1-x):x]; const c = pal[ch]; if (!c) continue; ctx.fillStyle = c; ctx.fillRect(leftX+x*s, topY+y*s, px, px); } }
  }

  start() {
    if (this.running) return; this.running = true; this.last = 0; this.resize();
    const raf: any = (this.win as any).requestAnimationFrame ? (this.win as any).requestAnimationFrame.bind(this.win) : requestAnimationFrame;
    this.raf = raf((t: number) => this.frame(t));
  }
  stop() {
    this.running = false;
    const caf: any = (this.win as any).cancelAnimationFrame ? (this.win as any).cancelAnimationFrame.bind(this.win) : cancelAnimationFrame;
    if (this.raf) caf(this.raf); this.raf = 0;
  }

  private frame(now: number) {
    if (!this.running) return;
    const raf: any = (this.win as any).requestAnimationFrame ? (this.win as any).requestAnimationFrame.bind(this.win) : requestAnimationFrame;
    this.raf = raf((t: number) => this.frame(t));
    const interval = 1000 / (this.cfg.fps || 60);
    if (this.last && now - this.last < interval) return;
    const dt = this.last ? Math.min(0.1, (now - this.last)/1000) : 0.016; this.last = now;
    if (!this.bg) this.buildBG();
    this.ensureFlock();
    for (const b of this.flock) b.step(dt, this.cfg, this.W, this.H);
    const ctx = this.ctx;
    if (this.bg) { ctx.setTransform(1,0,0,1,0,0); ctx.drawImage(this.bg,0,0); ctx.setTransform(this.dpr,0,0,this.dpr,0,0); }
    else { ctx.setTransform(this.dpr,0,0,this.dpr,0,0); ctx.fillStyle = shiftHue("#6f9e54", this.cfg.grassHue); ctx.fillRect(0,0,this.W,this.H); }
    const pal = woolPal(this.cfg);
    this.flock.slice().sort((a,b)=>a.y-b.y).forEach((b)=>this.drawSheep(b,pal));
  }
}
