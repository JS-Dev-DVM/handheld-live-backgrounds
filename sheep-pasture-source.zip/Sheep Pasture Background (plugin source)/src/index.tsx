import { definePlugin } from "@decky/api";
import { PanelSection, PanelSectionRow, ToggleField, SliderField } from "@decky/ui";
import { useState } from "react";
import { GiSheep } from "react-icons/gi";

import { SheepInjector } from "./injector";
import { DEFAULT_CONFIG, SheepConfig } from "./sheeppasture";

interface Settings {
  enabled: boolean;
  flock: number;       // 1..20
  size: number;        // 2..8 (sheep pixel scale)
  speed: number;       // 8..90 px/s
  calm: number;        // 0..100 (grazing tendency)
  scenery: number;     // 0..100 (trees/rocks/tufts)
  grassHue: number;    // -40..60
  woolTone: number;    // 0..100 -> wool hex
  wool: string;        // hex (exact)
  fps: number;         // 20..60
  pauseInGame: boolean;
}

const KEY = "sheep-pasture-bg.settings.v1";

// The single baked-in default ("Cozy flock", tuned in the preview).
const DEFAULTS: Settings = {
  enabled: true,
  flock: 8, size: 4, speed: 32, calm: 60, scenery: 55, grassHue: 0,
  woolTone: 70, wool: "#f1ede0", fps: 30, pauseInGame: true,
};

function load(): Settings {
  try { const raw = localStorage.getItem(KEY); if (raw) return { ...DEFAULTS, ...JSON.parse(raw) }; } catch { /* */ }
  return { ...DEFAULTS };
}
function save(s: Settings) { try { localStorage.setItem(KEY, JSON.stringify(s)); } catch { /* */ } }

// HSL -> hex. Used to derive the wool color from the "Wool tone" slider
// (warm, low-saturation, light: cream at low tone -> near-white at high tone).
function hslHex(h: number, s: number, l: number): string {
  const a = (s / 100) * Math.min(l / 100, 1 - l / 100);
  const f = (n: number) => {
    const k = (n + h / 30) % 12;
    const c = l / 100 - a * Math.max(-1, Math.min(k - 3, 9 - k, 1));
    return Math.round(255 * c).toString(16).padStart(2, "0");
  };
  return `#${f(0)}${f(8)}${f(4)}`;
}
function woolHex(tone: number): string { return hslHex(42, 22, 78 + tone * 0.18); }

function toConfig(s: Settings): SheepConfig {
  return {
    ...DEFAULT_CONFIG,
    flock: s.flock,
    size: s.size,
    speed: s.speed,
    calm: s.calm,
    scenery: s.scenery,
    grassHue: s.grassHue,
    wool: s.wool,
    fps: s.fps,
    pauseInGame: s.pauseInGame,
  };
}

let settings = load();
let injector: SheepInjector;
try {
  injector = new SheepInjector(toConfig(settings));
  if (settings.enabled) injector.start();
} catch (e) {
  console.error("[SheepPasture] init failed", e);
  injector = injector! ?? new SheepInjector(toConfig(settings));
}

function apply(next: Partial<Settings>) {
  settings = { ...settings, ...next };
  save(settings);
  try {
    injector.setConfig(toConfig(settings));
    if (settings.enabled) injector.start(); else injector.stop();
  } catch (e) { console.error("[SheepPasture] apply failed", e); }
}

function Content() {
  const [s, setS] = useState<Settings>(settings);
  const update = (p: Partial<Settings>) => { apply(p); setS({ ...settings }); };

  return (
    <PanelSection title="Sheep Pasture Background">
      <PanelSectionRow>
        <ToggleField label="Enabled" checked={s.enabled} onChange={(v) => update({ enabled: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Flock size" value={s.flock} min={1} max={20} step={1}
          onChange={(v) => update({ flock: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Sheep size" value={s.size} min={2} max={8} step={1}
          onChange={(v) => update({ size: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Walk speed" value={s.speed} min={8} max={90} step={2}
          onChange={(v) => update({ speed: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Calm (grazing)" value={s.calm} min={0} max={100} step={5}
          description="Higher = more standing & grazing"
          onChange={(v) => update({ calm: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Scenery" value={s.scenery} min={0} max={100} step={5}
          description="Trees, rocks & grass tufts"
          onChange={(v) => update({ scenery: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Grass hue" value={s.grassHue} min={-40} max={60} step={2}
          onChange={(v) => update({ grassHue: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Wool tone (cream → white)" value={s.woolTone} min={0} max={100} step={5}
          onChange={(v) => update({ woolTone: v, wool: woolHex(v) })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="FPS cap" value={s.fps} min={20} max={60} step={5}
          description="Lower = cooler & longer battery"
          onChange={(v) => update({ fps: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <ToggleField label="Pause in game" checked={s.pauseInGame} onChange={(v) => update({ pauseInGame: v })} />
      </PanelSectionRow>
    </PanelSection>
  );
}

export default definePlugin(() => ({
  name: "Sheep Pasture Background",
  titleView: <div>Sheep Pasture Background</div>,
  alwaysRender: false,
  content: <Content />,
  icon: <GiSheep />,
  onDismount() {
    try { injector.stop(); } catch (e) { console.error("[SheepPasture] onDismount failed", e); }
  },
}));
