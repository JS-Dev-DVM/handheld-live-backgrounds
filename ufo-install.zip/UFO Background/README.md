# UFO Background (Decky plugin)
Live monochrome UFO fleet, top+bottom activity zones. No stats overlay. Bazzite only.
QAM: Enabled, UFOs, Calm-Hyper, Invaders, Pause while playing.
