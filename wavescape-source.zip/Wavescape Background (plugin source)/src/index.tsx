import { definePlugin } from "@decky/api";
import { PanelSection, PanelSectionRow, ToggleField, SliderField } from "@decky/ui";
import { useState } from "react";
import { FaWater } from "react-icons/fa";

import { WaveInjector } from "./injector";
import { DEFAULT_CONFIG, WaveConfig } from "./wavescape";

interface Settings {
  enabled: boolean;
  speed: number;       // 0..300 -> /100 = 0..3.0
  lines: number;       // 8..70
  amp: number;         // 0..260
  thickness: number;   // 10..220
  posY: number;        // 0..100 -> /100 = vertical position (0 top .. 1 bottom)
  width: number;       // 4..30 -> /10 = 0.4..3.0
  glow: number;        // 20..100 -> /100 = 0.20..1.00
  complexity: number;  // 1..4
  fps: number;         // 20..60
  color: string;       // hex (exact)
  hue: number;         // recolor slider position; moving it overrides color
}

const KEY = "wavescape-bg.settings.v5";

// The single baked-in default (tuned in the Preset Studio).
const DEFAULTS: Settings = {
  enabled: true,
  speed: 25, lines: 9, amp: 202, thickness: 104, width: 19, glow: 100, posY: 40,
  complexity: 4, fps: 40, color: "#b8ffe8", hue: 160,
};

function load(): Settings {
  try { const raw = localStorage.getItem(KEY); if (raw) return { ...DEFAULTS, ...JSON.parse(raw) }; } catch { /* */ }
  return { ...DEFAULTS };
}
function save(s: Settings) { try { localStorage.setItem(KEY, JSON.stringify(s)); } catch { /* */ } }

function hslHex(h: number, s: number, l: number): string {
  if (h >= 360) return "#ffffff";
  const a = (s / 100) * Math.min(l / 100, 1 - l / 100);
  const f = (n: number) => {
    const k = (n + h / 30) % 12;
    const c = l / 100 - a * Math.max(-1, Math.min(k - 3, 9 - k, 1));
    return Math.round(255 * c).toString(16).padStart(2, "0");
  };
  return `#${f(0)}${f(8)}${f(4)}`;
}

function toConfig(s: Settings): WaveConfig {
  return {
    ...DEFAULT_CONFIG,
    speed: s.speed / 100,
    lines: s.lines,
    amp: s.amp,
    thickness: s.thickness,
    posY: s.posY / 100,
    width: s.width / 10,
    glow: s.glow / 100,
    complexity: s.complexity,
    fps: s.fps,
    color: s.color,
    background: "#000000",
  };
}

let settings = load();
let injector: WaveInjector;
try {
  injector = new WaveInjector(toConfig(settings));
  if (settings.enabled) injector.start();
} catch (e) {
  console.error("[Wavescape] init failed", e);
  injector = injector! ?? new WaveInjector(toConfig(settings));
}

function apply(next: Partial<Settings>) {
  settings = { ...settings, ...next };
  save(settings);
  try {
    injector.setConfig(toConfig(settings));
    if (settings.enabled) injector.start(); else injector.stop();
  } catch (e) { console.error("[Wavescape] apply failed", e); }
}

function Content() {
  const [s, setS] = useState<Settings>(settings);
  const update = (p: Partial<Settings>) => { apply(p); setS({ ...settings }); };

  return (
    <PanelSection title="Wavescape Background">
      <PanelSectionRow>
        <ToggleField label="Enabled" checked={s.enabled} onChange={(v) => update({ enabled: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Flow speed" value={s.speed} min={0} max={300} step={5}
          onChange={(v) => update({ speed: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Strands" value={s.lines} min={8} max={70} step={1}
          onChange={(v) => update({ lines: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Amplitude (wave height)" value={s.amp} min={0} max={260} step={2}
          onChange={(v) => update({ amp: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Thickness (fan depth)" value={s.thickness} min={10} max={220} step={2}
          onChange={(v) => update({ thickness: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Vertical position" value={s.posY} min={0} max={100} step={1}
          description="0 = top, 100 = bottom"
          onChange={(v) => update({ posY: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Line width (x10)" value={s.width} min={4} max={30} step={1}
          onChange={(v) => update({ width: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Front brightness" value={s.glow} min={20} max={100} step={1}
          onChange={(v) => update({ glow: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Complexity (octaves)" value={s.complexity} min={1} max={8} step={1} notchTicksVisible
          onChange={(v) => update({ complexity: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="FPS cap" value={s.fps} min={20} max={60} step={1}
          description="Lower = cooler & longer battery"
          onChange={(v) => update({ fps: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Color (hue, max=white)" value={s.hue} min={0} max={360} step={5}
          description="Move to recolor; default is the saved mint"
          onChange={(v) => update({ hue: v, color: hslHex(v, 85, 80) })} />
      </PanelSectionRow>
    </PanelSection>
  );
}

export default definePlugin(() => ({
  name: "Wavescape Background",
  titleView: <div>Wavescape Background</div>,
  alwaysRender: false,
  content: <Content />,
  icon: <FaWater />,
  onDismount() {
    try { injector.stop(); } catch (e) { console.error("[Wavescape] onDismount failed", e); }
  },
}));
