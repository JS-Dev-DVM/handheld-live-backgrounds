// wavescape.ts — framework-free canvas engine. Recreates mkvdb's "Minimal
// Wavescape": a fractal-noise (fBm) heightfield drawn as a stack of depth slices.
// A crisp white FRONT line rides the top, strands fan DOWNWARD and fade to dim
// gray at the back (exp depth falloff), drawn back-to-front so the front stays
// sharp. Organic noise — NOT sines. Original fBm impl (value noise), not the
// reference shader's code. Monochrome on black. Same math as the preview HTML.
// Performance: NO shadowBlur, capped DPR (<=2), an fps cap, adaptive sample step.

export interface WaveConfig {
  speed: number;       // scroll speed of the noise field (0..3)
  lines: number;       // depth slices / strands (8..70)
  amp: number;         // wave height, px (0..260)
  thickness: number;   // downward fan depth across the stack, px (10..220)
  posY: number;        // vertical center of the ribbon, fraction of height (0..1)
  width: number;       // line width, px (0.4..3)
  glow: number;        // front-line brightness/intensity (0.2..1)
  complexity: number;  // fBm octaves (1..8)
  fps: number;         // frame cap (20..60) — battery/heat control
  color: string;       // hex, monochrome (front line color)
  background: string;  // hex, cleared each frame
}

export const DEFAULT_CONFIG: WaveConfig = {
  speed: 0.25, lines: 9, amp: 202, thickness: 104, width: 1.9, glow: 1.0, posY: 0.40,
  complexity: 4, fps: 40, color: "#b8ffe8", background: "#000000",
};

// look constants (tuned to the reference)
const NX = 2.4;      // horizontal noise frequency across the screen width
const NZ = 0.16;     // depth spacing between adjacent strands in noise space
const SCROLL = 0.16; // depth scroll per second (* speed)
const BACK_FLOOR = 0.13;
const FALLOFF = 1.8; // gamma — concentrates brightness near the front line

function hexRgb(h: string): [number, number, number] {
  let s = (h || "#ffffff").replace("#", "");
  if (s.length === 3) s = s.split("").map((c) => c + c).join("");
  return [parseInt(s.slice(0, 2), 16), parseInt(s.slice(2, 4), 16), parseInt(s.slice(4, 6), 16)];
}

// --- original value-noise + fBm (mine, not the reference shader's simplex) ---
function hash2(x: number, y: number): number {
  const s = Math.sin(x * 127.1 + y * 311.7) * 43758.5453;
  return s - Math.floor(s); // 0..1
}
function vnoise(x: number, y: number): number {
  const xi = Math.floor(x), yi = Math.floor(y);
  const xf = x - xi, yf = y - yi;
  const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
  const a = hash2(xi, yi), b = hash2(xi + 1, yi), c = hash2(xi, yi + 1), d = hash2(xi + 1, yi + 1);
  const top = a + (b - a) * u, bot = c + (d - c) * u;
  return (top + (bot - top) * v) * 2 - 1; // -1..1
}
function fbm(x: number, y: number, octaves: number): number {
  let sum = 0, amp = 0.5, fx = x, fy = y;
  for (let o = 0; o < octaves; o++) {
    sum += amp * vnoise(fx, fy);
    fx = fx * 2.02 + 0.13; fy = fy * 2.02 - 0.07;
    amp *= 0.5;
  }
  return sum;
}

export class Wavescape {
  private ctx: CanvasRenderingContext2D;
  private cfg: WaveConfig;
  private W = 0; private H = 0; private step = 6;
  private raf = 0; private last = 0; private running = false;
  private rgb: [number, number, number] = [255, 255, 255];
  private win: Window = (typeof window !== "undefined" ? window : (globalThis as any));

  constructor(private canvas: HTMLCanvasElement, cfg: WaveConfig, win?: Window) {
    this.cfg = { ...cfg };
    if (win) this.win = win;
    const c = canvas.getContext("2d", { alpha: false });
    if (!c) throw new Error("2d context unavailable");
    this.ctx = c;
    this.rgb = hexRgb(this.cfg.color);
  }

  setConfig(p: Partial<WaveConfig>) {
    Object.assign(this.cfg, p);
    if (p.color !== undefined) this.rgb = hexRgb(this.cfg.color);
  }

  resize() {
    const r = this.canvas.getBoundingClientRect();
    this.W = Math.max(1, r.width || this.canvas.clientWidth || 1280);
    this.H = Math.max(1, r.height || this.canvas.clientHeight || 800);
    const dpr = Math.min(this.win.devicePixelRatio || 1, 2);
    this.canvas.width = Math.floor(this.W * dpr);
    this.canvas.height = Math.floor(this.H * dpr);
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    this.step = Math.max(5, Math.floor(this.W / 220));
  }

  start() {
    if (this.running) return;
    this.running = true;
    this.last = 0;
    this.resize();
    const raf: any = (this.win as any).requestAnimationFrame
      ? (this.win as any).requestAnimationFrame.bind(this.win) : requestAnimationFrame;
    this.raf = raf((t: number) => this.frame(t));
  }

  stop() {
    this.running = false;
    const caf: any = (this.win as any).cancelAnimationFrame
      ? (this.win as any).cancelAnimationFrame.bind(this.win) : cancelAnimationFrame;
    if (this.raf) caf(this.raf);
    this.raf = 0;
  }

  private frame(now: number) {
    if (!this.running) return;
    const raf: any = (this.win as any).requestAnimationFrame
      ? (this.win as any).requestAnimationFrame.bind(this.win) : requestAnimationFrame;
    this.raf = raf((t: number) => this.frame(t));

    const interval = 1000 / (this.cfg.fps || 60);
    if (now - this.last < interval) return;
    this.last = now;

    const ctx = this.ctx;
    const [cr, cg, cb] = this.rgb;
    const W = this.W, H = this.H, step = this.step;
    const sp = this.cfg.speed;
    const T = (now / 1000) * sp;
    const oct = Math.max(1, Math.min(8, this.cfg.complexity | 0));
    const n = Math.max(2, this.cfg.lines | 0);
    const amp = this.cfg.amp;
    const thick = this.cfg.thickness;
    const intensity = this.cfg.glow;
    const baseY = H * (this.cfg.posY ?? 0.40);
    const scroll = T * SCROLL;

    ctx.globalCompositeOperation = "source-over"; // layered painter's order, no bloom
    ctx.fillStyle = this.cfg.background;
    ctx.fillRect(0, 0, W, H);
    ctx.lineWidth = this.cfg.width;
    ctx.lineJoin = "round";

    // draw BACK strands first (dim), FRONT line last (bright) so it stays crisp
    for (let i = n - 1; i >= 0; i--) {
      const frac = i / (n - 1);                       // 0 = front/top, 1 = back/bottom
      const bright = BACK_FLOOR + (1 - BACK_FLOOR) * Math.pow(1 - frac, FALLOFF);
      const a = Math.min(1, bright * intensity);
      ctx.strokeStyle = `rgba(${cr},${cg},${cb},${a.toFixed(3)})`;
      // fan depth pulses slowly along the stack so strands bunch and spread
      const fan = 0.30 + 0.70 * (0.5 + 0.5 * Math.sin(frac * 6.28 * 0.5 - T * 0.4));
      ctx.beginPath();
      for (let x = 0; x <= W + step; x += step) {
        const u = x / W;
        // organic fBm heightfield; depth coord = this strand's slice (+scroll)
        const h = fbm(u * NX, frac * NZ + scroll, oct);
        const y = baseY + frac * thick * fan + amp * h;
        if (x === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }
  }
}
