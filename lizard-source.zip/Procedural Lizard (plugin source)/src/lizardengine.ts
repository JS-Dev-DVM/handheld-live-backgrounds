// @ts-nocheck
// lizardengine.ts — autonomous procedural lizard, ported faithfully from the
// "Interactive Reptile Cursor" wallpaper (Segment / LimbSystem / LegSystem /
// Creature / setupLizard). Only behavioural change vs the original: no mouse on a
// handheld in Game Mode, so the creature steers toward its own wander target.
// Factory contract used by the injector:
//   createLizardEngine(canvas, cfg, win) -> { start, stop, setConfig, setStats, resize }
//
// Tunable cfg (defaults reproduce the originally-approved look):
//   count, size, speedMul         — how many / scale / crawl speed
//   legs (pairs), tail (segments) — anatomy
//   turn   (1..10)                — steering agility (default 5 == original)
//   restless (0..100)             — how often it re-picks a wander target
//   width                         — line thickness
//   color                         — stroke colour (CSS)
//   glow   (0..100)               — line bloom via shadowBlur (0 = off, cheap)
//   trail  (0..90)                — motion ghosting (0 = hard clear, original)
//   avoidBand (0/1)               — keep targets out of the central tile strip
//   fps                           — frame cap

export function createLizardEngine(canvas, cfg, win) {
  const cv = canvas;
  const doc = cv.ownerDocument;
  const ctx = cv.getContext("2d", { alpha: false });

  let DPR = 1, W = 2, H = 2;
  let raf = 0, running = false, last = 0, waveT = 0;
  let lizards = [];
  let segmentCount = 0;

  function color() { return cfg.color || "#f2f5fa"; }
  function lineW() { return Math.max(1, (cfg.width || 1.5)) * DPR; }

  function resize() {
    DPR = Math.min(2, win.devicePixelRatio || 1);
    const r = cv.getBoundingClientRect();
    const cw = Math.max(2, r.width), ch = Math.max(2, r.height);
    cv.width = Math.round(cw * DPR);
    cv.height = Math.round(ch * DPR);
    W = cv.width; H = cv.height;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    build();
  }

  // ───────────────────────── ported classes ─────────────────────────
  class Segment {
    constructor(parent, size, angle, range, stiffness) {
      segmentCount++;
      this.isSegment = true;
      this.parent = parent;
      if (typeof parent.children == "object") parent.children.push(this);
      this.children = [];
      this.size = size;
      this.relAngle = angle;
      this.defAngle = angle;
      this.absAngle = parent.absAngle + angle;
      this.range = range;
      this.stiffness = stiffness;
      this.updateRelative(false, true);
    }
    updateRelative(iter, flex) {
      this.relAngle = this.relAngle - 2 * Math.PI * Math.floor((this.relAngle - this.defAngle) / 2 / Math.PI + 0.5);
      if (flex) {
        if (this.wave && cfg.slither) this.relAngle += (cfg.slither / 100) * 0.55 * Math.sin(waveT - this.waveIdx * 0.55);
        this.relAngle = Math.min(this.defAngle + this.range / 2,
          Math.max(this.defAngle - this.range / 2,
            (this.relAngle - this.defAngle) / this.stiffness + this.defAngle));
      }
      this.absAngle = this.parent.absAngle + this.relAngle;
      this.x = this.parent.x + Math.cos(this.absAngle) * this.size;
      this.y = this.parent.y + Math.sin(this.absAngle) * this.size;
      if (iter) for (let i = 0; i < this.children.length; i++) this.children[i].updateRelative(iter, flex);
    }
    draw(iter) {
      ctx.beginPath();
      ctx.moveTo(this.parent.x, this.parent.y);
      ctx.lineTo(this.x, this.y);
      ctx.stroke();
      if (iter) for (let i = 0; i < this.children.length; i++) this.children[i].draw(true);
    }
    follow(iter) {
      const x = this.parent.x, y = this.parent.y;
      const dist = Math.sqrt((this.x - x) ** 2 + (this.y - y) ** 2);
      if (dist > 0.0001) {
        this.x = x + this.size * (this.x - x) / dist;
        this.y = y + this.size * (this.y - y) / dist;
      }
      this.absAngle = Math.atan2(this.y - y, this.x - x);
      this.relAngle = this.absAngle - this.parent.absAngle;
      this.updateRelative(false, true);
      if (iter) for (let i = 0; i < this.children.length; i++) this.children[i].follow(true);
    }
  }

  class LimbSystem {
    constructor(end, length, speed, creature) {
      this.end = end;
      this.length = Math.max(1, length);
      this.creature = creature;
      this.speed = speed;
      creature.systems.push(this);
      this.nodes = [];
      let node = end;
      for (let i = 0; i < length; i++) {
        this.nodes.unshift(node);
        node = node.parent;
        if (!node || !node.isSegment) { this.length = i + 1; break; }
      }
      this.hip = this.nodes[0].parent;
    }
    moveTo(x, y) {
      this.nodes[0].updateRelative(true, true);
      const dist = Math.sqrt((x - this.end.x) ** 2 + (y - this.end.y) ** 2);
      let len = Math.max(0, dist - this.speed);
      for (let i = this.nodes.length - 1; i >= 0; i--) {
        const node = this.nodes[i];
        const ang = Math.atan2(node.y - y, node.x - x);
        node.x = x + len * Math.cos(ang);
        node.y = y + len * Math.sin(ang);
        x = node.x; y = node.y; len = node.size;
      }
      for (let i = 0; i < this.nodes.length; i++) {
        const node = this.nodes[i];
        node.absAngle = Math.atan2(node.y - node.parent.y, node.x - node.parent.x);
        node.relAngle = node.absAngle - node.parent.absAngle;
        for (let ii = 0; ii < node.children.length; ii++) {
          const childNode = node.children[ii];
          if (!this.nodes.includes(childNode)) childNode.updateRelative(true, false);
        }
      }
    }
    update(x, y) { this.moveTo(x, y); }
  }

  class LegSystem extends LimbSystem {
    constructor(end, length, speed, creature) {
      super(end, length, speed, creature);
      this.goalX = end.x; this.goalY = end.y;
      this.step = 0; this.forwardness = 0;
      this.reach = 0.9 * Math.sqrt((this.end.x - this.hip.x) ** 2 + (this.end.y - this.hip.y) ** 2);
      let relAngle = this.creature.absAngle - Math.atan2(this.end.y - this.hip.y, this.end.x - this.hip.x);
      relAngle -= 2 * Math.PI * Math.floor(relAngle / 2 / Math.PI + 0.5);
      this.swing = -relAngle + (2 * (relAngle < 0) - 1) * Math.PI / 2;
      this.swingOffset = this.creature.absAngle - this.hip.absAngle;
    }
    update(x, y) {
      this.moveTo(this.goalX, this.goalY);
      if (this.step == 0) {
        const dist = Math.sqrt((this.end.x - this.goalX) ** 2 + (this.end.y - this.goalY) ** 2);
        if (dist > 1) {
          this.step = 1;
          this.goalX = this.hip.x + this.reach * Math.cos(this.swing + this.hip.absAngle + this.swingOffset) + (2 * Math.random() - 1) * this.reach / 2;
          this.goalY = this.hip.y + this.reach * Math.sin(this.swing + this.hip.absAngle + this.swingOffset) + (2 * Math.random() - 1) * this.reach / 2;
        }
      } else if (this.step == 1) {
        const theta = Math.atan2(this.end.y - this.hip.y, this.end.x - this.hip.x) - this.hip.absAngle;
        const dist = Math.sqrt((this.end.x - this.hip.x) ** 2 + (this.end.y - this.hip.y) ** 2);
        const forwardness2 = dist * Math.cos(theta);
        const dF = this.forwardness - forwardness2;
        this.forwardness = forwardness2;
        if (dF * dF < 1) {
          this.step = 0;
          this.goalX = this.hip.x + (this.end.x - this.hip.x);
          this.goalY = this.hip.y + (this.end.y - this.hip.y);
        }
      }
    }
  }

  class Creature {
    constructor(x, y, angle, fAccel, fFric, fRes, fThresh, rAccel, rFric, rRes, rThresh) {
      this.x = x; this.y = y; this.absAngle = angle;
      this.fSpeed = 0; this.fAccel = fAccel; this.fFric = fFric; this.fRes = fRes; this.fThresh = fThresh;
      this.rSpeed = 0; this.rAccel = rAccel; this.rFric = rFric; this.rRes = rRes; this.rThresh = rThresh;
      this.children = []; this.systems = [];
      this.tx = x; this.ty = y;
    }
    follow(x, y) {
      const dist = Math.sqrt((this.x - x) ** 2 + (this.y - y) ** 2);
      const angle = Math.atan2(y - this.y, x - this.x);
      let accel = this.fAccel;
      if (this.systems.length > 0) {
        let sum = 0;
        for (let i = 0; i < this.systems.length; i++) sum += (this.systems[i].step == 0);
        accel *= sum / this.systems.length;
      }
      this.fSpeed += accel * (dist > this.fThresh);
      this.fSpeed *= 1 - this.fRes;
      this.speed = Math.max(0, this.fSpeed - this.fFric);
      let dif = this.absAngle - angle;
      dif -= 2 * Math.PI * Math.floor(dif / (2 * Math.PI) + 0.5);
      if (Math.abs(dif) > this.rThresh && dist > this.fThresh) {
        this.rSpeed -= this.rAccel * (2 * (dif > 0) - 1);
      }
      this.rSpeed *= 1 - this.rRes;
      if (Math.abs(this.rSpeed) > this.rFric) this.rSpeed -= this.rFric * (2 * (this.rSpeed > 0) - 1);
      else this.rSpeed = 0;
      this.absAngle += this.rSpeed;
      this.absAngle -= 2 * Math.PI * Math.floor(this.absAngle / (2 * Math.PI) + 0.5);
      this.x += this.speed * Math.cos(this.absAngle);
      this.y += this.speed * Math.sin(this.absAngle);
      this.absAngle += Math.PI;
      for (let i = 0; i < this.children.length; i++) this.children[i].follow(true, true);
      for (let i = 0; i < this.systems.length; i++) this.systems[i].update(x, y);
      this.absAngle -= Math.PI;
      this.draw(true);
    }
    draw(iter) {
      const r = 4 * DPR;
      ctx.beginPath();
      ctx.arc(this.x, this.y, r, Math.PI / 4 + this.absAngle, 7 * Math.PI / 4 + this.absAngle);
      ctx.moveTo(this.x + r * Math.cos(7 * Math.PI / 4 + this.absAngle), this.y + r * Math.sin(7 * Math.PI / 4 + this.absAngle));
      ctx.lineTo(this.x + r * Math.cos(this.absAngle) * Math.sqrt(2), this.y + r * Math.sin(this.absAngle) * Math.sqrt(2));
      ctx.lineTo(this.x + r * Math.cos(Math.PI / 4 + this.absAngle), this.y + r * Math.sin(Math.PI / 4 + this.absAngle));
      ctx.stroke();
      if (iter) for (let i = 0; i < this.children.length; i++) this.children[i].draw(true);
    }
  }

  function setupLizard(s, legs, tail, startX, startY) {
    const turn = Math.max(1, Math.min(10, cfg.turn ?? 5));
    const rThresh = Math.max(0.08, 0.45 - 0.03 * turn); // default turn 5 -> 0.30 (original)
    const rAccel = 0.05 + 0.007 * turn;                 // default turn 5 -> 0.085 (original)
    const critter = new Creature(startX, startY, Math.random() * Math.PI * 2,
      s * 10 * (cfg.speedMul || 1), s * 2, 0.5, 16, rAccel, 0.5, 0.5, rThresh);
    let spinal = critter; let bk = 0;
    for (let i = 0; i < 6; i++) {
      spinal = new Segment(spinal, s * 4, 0, Math.PI * 2 / 3, 1.1);
      spinal.wave = true; spinal.waveIdx = bk++;
      for (let ii = -1; ii <= 1; ii += 2) {
        let node = new Segment(spinal, s * 3, ii, 0.1, 2);
        for (let iii = 0; iii < 3; iii++) node = new Segment(node, s * 0.1, -ii * 0.1, 0.1, 2);
      }
    }
    for (let i = 0; i < legs; i++) {
      if (i > 0) {
        for (let ii = 0; ii < 6; ii++) {
          spinal = new Segment(spinal, s * 4, 0, 1.571, 1.5);
          spinal.wave = true; spinal.waveIdx = bk++;
          for (let iii = -1; iii <= 1; iii += 2) {
            let node = new Segment(spinal, s * 3, iii * 1.571, 0.1, 1.5);
            for (let iv = 0; iv < 3; iv++) node = new Segment(node, s * 3, -iii * 0.3, 0.1, 2);
          }
        }
      }
      for (let ii = -1; ii <= 1; ii += 2) {
        let node = new Segment(spinal, s * 12, ii * 0.785, 0, 8);
        node = new Segment(node, s * 16, -ii * 0.785, 6.28, 1);
        node = new Segment(node, s * 16, ii * 1.571, Math.PI, 2);
        for (let iii = 0; iii < 4; iii++) new Segment(node, s * 4, (iii / 3 - 0.5) * 1.571, 0.1, 4);
        new LegSystem(node, 3, s * 12, critter);
      }
    }
    for (let i = 0; i < tail; i++) {
      spinal = new Segment(spinal, s * 4, 0, Math.PI * 2 / 3, 1.1);
      spinal.wave = true; spinal.waveIdx = bk++;
      for (let ii = -1; ii <= 1; ii += 2) {
        let node = new Segment(spinal, s * 3, ii, 0.1, 2);
        for (let iii = 0; iii < 3; iii++) node = new Segment(node, s * 3 * (tail - i) / tail, -ii * 0.1, 0.1, 2);
      }
    }
    return critter;
  }

  function pickTarget(c, inner) {
    let x, y, tries = 0;
    const lo = inner ? 0.25 : 0.05, span = inner ? 0.5 : 0.9;
    do {
      x = W * (lo + span * Math.random());
      y = H * (lo + span * Math.random());
      tries++;
    } while (cfg.avoidBand && y > H * 0.32 && y < H * 0.68 && tries < 12);
    c.tx = x; c.ty = y;
  }

  // walk the whole creature tree (root Creature + every Segment)
  function eachNode(c, fn) {
    fn(c);
    const st = c.children.slice();
    while (st.length) { const n = st.pop(); fn(n); for (let i = 0; i < n.children.length; i++) st.push(n.children[i]); }
  }
  function bounds(c) {
    let a = 1e9, b = -1e9, d = 1e9, e = -1e9;
    eachNode(c, n => { if (n.x < a) a = n.x; if (n.x > b) b = n.x; if (n.y < d) d = n.y; if (n.y > e) e = n.y; });
    return { minX: a, maxX: b, minY: d, maxY: e };
  }
  function translate(c, dx, dy) { eachNode(c, n => { n.x += dx; n.y += dy; }); }

  function build() {
    segmentCount = 0;
    lizards = [];
    const s = Math.max(0.6, (cfg.size || 3)) * DPR;
    const legs = Math.max(1, Math.round(cfg.legs ?? 5));
    const tail = Math.max(0, Math.round(cfg.tail ?? 45));
    const n = Math.max(1, Math.round(cfg.count || 1));
    for (let i = 0; i < n; i++) {
      const c = setupLizard(s, legs, tail, W * (0.2 + 0.6 * Math.random()), H * (0.2 + 0.6 * Math.random()));
      pickTarget(c);
      lizards.push(c);
    }
  }

  function frame(now) {
    if (!running) return;
    raf = win.requestAnimationFrame(frame);
    const fps = cfg.fps || 30;
    if (now - last < 1000 / fps) return;
    last = now;
    waveT += 0.16 * (cfg.slitherSpeed || 1);

    // clear (or fade for motion trail)
    const trail = Math.max(0, Math.min(90, cfg.trail || 0));
    ctx.globalAlpha = 1;
    ctx.fillStyle = trail > 0 ? "rgba(0,0,0," + (1 - trail / 100).toFixed(3) + ")" : "#000";
    ctx.fillRect(0, 0, W, H);

    ctx.strokeStyle = color();
    ctx.fillStyle = color();
    ctx.lineWidth = lineW();
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    const glow = Math.max(0, Math.min(100, cfg.glow || 0));
    if (glow > 0) { ctx.shadowBlur = glow / 100 * 14 * DPR; ctx.shadowColor = color(); }
    else { ctx.shadowBlur = 0; }

    const reach = (cfg.size || 3) * DPR * 14;
    const restless = Math.max(0, Math.min(100, cfg.restless ?? 30)) / 100;
    const wrap = !!cfg.edge;          // 0 = stay inside (soft walls), 1 = wrap (snake)
    const m = Math.min(W, H) * 0.06;  // wall margin for stay-inside
    for (const c of lizards) {
      if (Math.hypot(c.x - c.tx, c.y - c.ty) < reach || Math.random() < restless * 0.004) pickTarget(c);
      c.follow(c.tx, c.ty);
      if (wrap) {
        // only wrap once the ENTIRE body has left an edge -> reappears whole on the far side
        const B = bounds(c);
        if (B.minX > W) translate(c, -B.maxX, 0);
        else if (B.maxX < 0) translate(c, W - B.minX, 0);
        if (B.minY > H) translate(c, 0, -B.maxY);
        else if (B.maxY < 0) translate(c, 0, H - B.minY);
      } else {
        // pre-emptive inward curve: bank the long body away BEFORE it reaches a wall
        const tm = Math.min(W, H) * 0.16;
        let pax = 0, pay = 0;
        if (c.x < tm) pax += 1; else if (c.x > W - tm) pax -= 1;
        if (c.y < tm) pay += 1; else if (c.y > H - tm) pay -= 1;
        if (pax || pay) {
          const want = Math.atan2(pay, pax);
          let d = want - c.absAngle; d -= 2 * Math.PI * Math.floor(d / (2 * Math.PI) + 0.5);
          c.absAngle += d * 0.15;
        }
        // hard safety clamp + retarget inward so it can never fully leave
        let hit = false;
        if (c.x < m) { c.x = m; hit = true; } else if (c.x > W - m) { c.x = W - m; hit = true; }
        if (c.y < m) { c.y = m; hit = true; } else if (c.y > H - m) { c.y = H - m; hit = true; }
        if (hit) { c.fSpeed *= 0.6; pickTarget(c, true); }
      }
    }
    ctx.shadowBlur = 0;
  }

  function start() {
    if (running) return;
    running = true; last = 0;
    if (!lizards.length) build();
    raf = win.requestAnimationFrame(frame);
  }
  function stop() {
    running = false;
    if (raf) { try { (win.cancelAnimationFrame || cancelAnimationFrame)(raf); } catch (e) {} raf = 0; }
  }
  function setConfig(p) {
    const STRUCT = ["count", "size", "legs", "tail", "speedMul", "turn"];
    const structural = STRUCT.some(k => k in p && p[k] !== cfg[k]);
    Object.assign(cfg, p);
    if (structural) build();
  }
  function setStats() { /* no backend — lizard has no CPU/GPU readout */ }

  return { start, stop, setConfig, setStats, resize };
}
