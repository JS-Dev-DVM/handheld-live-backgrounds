import { definePlugin } from "@decky/api";
import { PanelSection, PanelSectionRow, ToggleField, SliderField } from "@decky/ui";
import { useState } from "react";
import { FaDragon } from "react-icons/fa";

import { LizardInjector } from "./injector";

type Cfg = Record<string, number>;

// ── Baked look (approved 2026-06-18). Cosmetics fixed; the rest is exposed below ──
const BAKED: Cfg = { slither: 0, width: 1.5, glow: 0, trail: 0 }; // colour defaults white in engine

interface Settings {
  enabled: boolean;
  pauseInGame: boolean;
  count: number;     // 1..4 lizards
  size: number;      // 1.5..6
  speed: number;     // 1..8  (speedMul = speed/3.5)
  legs: number;      // 1..6 leg pairs
  tail: number;      // 0..70 tail segments
  turn: number;      // 1..10 steering agility
  restless: number;  // 0..100 how often it re-targets
  wrap: boolean;     // edge: wrap around screen (snake-loop) vs stay inside
  avoidBand: boolean;// keep off the central game-tile strip
  fps: number;       // 20..60 cap
}

const KEY = "lizard-bg.settings.v2"; // bumped from v1 (defaults + controls changed)

// Defaults = the preset sea approved
const DEFAULTS: Settings = {
  enabled: true,
  pauseInGame: true,
  count: 1,
  size: 4,
  speed: 3.5,
  legs: 5,
  tail: 45,
  turn: 3,
  restless: 30,
  wrap: true,
  avoidBand: true,
  fps: 20,
};

function load(): Settings {
  try { const raw = localStorage.getItem(KEY); if (raw) return { ...DEFAULTS, ...JSON.parse(raw) }; } catch { /* */ }
  return { ...DEFAULTS };
}
function save(s: Settings) { try { localStorage.setItem(KEY, JSON.stringify(s)); } catch { /* */ } }

function toConfig(s: Settings): Cfg {
  return {
    ...BAKED,
    count: s.count,
    size: s.size,
    speedMul: s.speed / 3.5,
    legs: s.legs,
    tail: s.tail,
    turn: s.turn,
    restless: s.restless,
    edge: s.wrap ? 1 : 0,
    avoidBand: s.avoidBand ? 1 : 0,
    fps: s.fps,
  };
}

let settings = load();
let injector: LizardInjector;
try {
  injector = new LizardInjector(toConfig(settings), settings.pauseInGame);
  if (settings.enabled) injector.start();
} catch (e) {
  console.error("[LIZARD-BG] init failed", e);
  injector = injector! ?? new LizardInjector(toConfig(settings), settings.pauseInGame);
}

function apply(next: Partial<Settings>) {
  settings = { ...settings, ...next };
  save(settings);
  try {
    injector.setPauseInGame(settings.pauseInGame);
    injector.setConfig(toConfig(settings));
    if (settings.enabled) injector.start(); else injector.stop();
  } catch (e) { console.error("[LIZARD-BG] apply failed", e); }
}

function Content() {
  const [s, setS] = useState<Settings>(settings);
  const update = (p: Partial<Settings>) => { apply(p); setS({ ...settings }); };

  return (
    <PanelSection title="Procedural Lizard">
      <PanelSectionRow>
        <ToggleField label="Enabled" checked={s.enabled} onChange={(v) => update({ enabled: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Lizards" value={s.count} min={1} max={4} step={1} notchTicksVisible
          description="How many roam the home screen" onChange={(v) => update({ count: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Size" value={s.size} min={1.5} max={6} step={0.5}
          description="Body scale" onChange={(v) => update({ size: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Speed" value={s.speed} min={1} max={8} step={0.5}
          description="How fast it crawls" onChange={(v) => update({ speed: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Leg pairs" value={s.legs} min={1} max={6} step={1} notchTicksVisible
          description="Number of leg sections" onChange={(v) => update({ legs: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Tail length" value={s.tail} min={0} max={70} step={1}
          description="Tail segment count" onChange={(v) => update({ tail: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Turn agility" value={s.turn} min={1} max={10} step={1}
          description="How sharply it steers" onChange={(v) => update({ turn: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Restlessness" value={s.restless} min={0} max={100} step={5}
          description="How often it picks a new direction" onChange={(v) => update({ restless: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Max FPS" value={s.fps} min={20} max={60} step={10} notchTicksVisible
          description="Frame cap (lower = better battery)" onChange={(v) => update({ fps: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <ToggleField label="Wrap around screen" checked={s.wrap}
          description="On: walks off one edge and reappears on the other (Snake-style). Off: stays inside."
          onChange={(v) => update({ wrap: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <ToggleField label="Avoid game-tile band" checked={s.avoidBand}
          description="Keeps it out of the central strip so it doesn't crawl over your library art"
          onChange={(v) => update({ avoidBand: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <ToggleField label="Pause while playing" checked={s.pauseInGame}
          description="Saves battery: freezes the animation when a game is running"
          onChange={(v) => update({ pauseInGame: v })} />
      </PanelSectionRow>
    </PanelSection>
  );
}

export default definePlugin(() => ({
  name: "Procedural Lizard",
  titleView: <div>Procedural Lizard</div>,
  alwaysRender: false,
  content: <Content />,
  icon: <FaDragon />,
  onDismount() {
    try { injector.stop(); } catch (e) { console.error("[LIZARD-BG] onDismount failed", e); }
  },
}));
