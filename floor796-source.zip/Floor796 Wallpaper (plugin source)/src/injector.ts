// injector.ts — mounts a full-screen <iframe> (the local floor796 page) over the
// largest full-screen art layer across every reachable Steam document.
// Adapted from the proven Matrix/UFO canvas injector. Battery: ONE mount only,
// and the iframe is UNLOADED (src=about:blank) while a game is running.

import { findSP, getGamepadNavigationTrees, Router } from "@decky/ui";

const FRAME_CLASS = "floor796-bg-frame";
const REL_CLASS = "floor796-bg-rel";
const STYLE_ID = "floor796-bg-style";
const LOG = "[Floor796]";
const MAX_MOUNTS = 1; // a wallpaper needs one layer; each iframe loads a big file

const HOST_CSS = `
.${REL_CLASS}{position:relative !important;}
.${FRAME_CLASS}{position:absolute !important; inset:0 !important; width:100% !important; height:100% !important;
  border:0 !important; margin:0 !important; z-index:2147483646 !important; pointer-events:none !important;
  display:block !important; background:#000 !important;}`;

function collectDocs(): Document[] {
  const set = new Set<Document>();
  const add = (d?: Document | null) => { if (d && d.body) set.add(d); };
  try { add(document); } catch {}
  try { add(findSP()?.document); } catch {}
  try { const t = getGamepadNavigationTrees?.(); if (Array.isArray(t)) for (const x of t) { try { add(x?.Root?.Element?.ownerDocument); } catch {} } } catch {}
  try {
    const ws: any = (Router as any)?.WindowStore; const rs: any[] = [];
    if (ws) { if (ws.GamepadUIMainWindowInstance) rs.push(ws.GamepadUIMainWindowInstance); if (Array.isArray(ws.SteamUIWindows)) rs.push(...ws.SteamUIWindows); if (Array.isArray(ws.OverlayWindows)) rs.push(...ws.OverlayWindows); }
    for (const r of rs) { try { add(r?.BrowserWindow?.document); } catch {} }
  } catch {}
  try { add((window as any).SteamUIStore?.GetFocusedWindowInstance?.()?.BrowserWindow?.document); } catch {}
  for (const d of [...set]) { try { d.querySelectorAll("iframe").forEach((f) => { try { add((f as HTMLIFrameElement).contentDocument); } catch {} }); } catch {} }
  return [...set];
}

function gameRunning(): boolean { try { return !!(Router as any)?.MainRunningApp; } catch { return false; } }

interface Mount { el: HTMLElement; frame: HTMLIFrameElement; isImg: boolean; prevOpacity: string; doc: Document; win: Window; }

export class Floor796Injector {
  private mounts: Mount[] = [];
  private timer = 0;
  private diagTimer = 0;
  private running = false;
  private paused = false;
  private pauseInGame = true;
  private styledDocs = new WeakSet<Document>();
  private pilled = false;
  private url = "";
  private opacity = 1;

  constructor(url: string, pauseInGame: boolean, opacity: number) {
    this.url = url; this.pauseInGame = pauseInGame; this.opacity = opacity;
  }

  private src(): string { return this.url || "about:blank"; }

  setUrl(u: string) {
    if (u === this.url) return;
    this.url = u;
    for (const m of this.mounts) { try { if (!(this.pauseInGame && gameRunning())) m.frame.src = this.src(); } catch {} }
    if (this.running && this.url && !this.mounts.length) this.tick();
  }
  setPauseInGame(b: boolean) { this.pauseInGame = b; }
  setOpacity(o: number) { this.opacity = o; for (const m of this.mounts) { try { m.frame.style.opacity = String(o); } catch {} } }
  reload() {
    if (!this.mounts.length) { this.tick(); return; }
    for (const m of this.mounts) {
      try {
        const u = this.src(); m.frame.src = "about:blank";
        const w: any = m.win; (w.setTimeout || setTimeout)(() => { try { m.frame.src = u; } catch {} }, 80);
      } catch {}
    }
  }

  start() {
    if (this.running) return;
    this.running = true;
    this.tick();
    const w: any = (typeof window !== "undefined" ? window : globalThis);
    this.timer = (w.setInterval || setInterval)(() => this.tick(), 1200);
    this.diagTimer = (w.setTimeout || setTimeout)(() => { if (!this.mounts.length) this.showDiag(); }, 5000);
    console.log(`${LOG} started`);
  }

  stop() {
    this.running = false;
    const w: any = (typeof window !== "undefined" ? window : globalThis);
    if (this.timer) { (w.clearInterval || clearInterval)(this.timer); this.timer = 0; }
    if (this.diagTimer) { (w.clearTimeout || clearTimeout)(this.diagTimer); this.diagTimer = 0; }
    for (const m of this.mounts) {
      try { m.frame.src = "about:blank"; } catch {}
      try { m.frame.remove(); } catch {}
      try { if (m.isImg) m.el.style.opacity = m.prevOpacity; m.el.classList.remove(REL_CLASS); } catch {}
      try { m.doc.getElementById("floor796-pill")?.remove(); m.doc.getElementById("floor796-diag")?.remove(); } catch {}
    }
    this.mounts = []; this.pilled = false;
    console.log(`${LOG} stopped`);
  }

  private ensureStyle(d: Document) { if (this.styledDocs.has(d) || d.getElementById(STYLE_ID)) { this.styledDocs.add(d); return; } const s = d.createElement("style"); s.id = STYLE_ID; s.textContent = HOST_CSS; d.head.appendChild(s); this.styledDocs.add(d); }

  private candidates(): { el: HTMLElement; doc: Document; win: Window; isImg: boolean; area: number }[] {
    const out: { el: HTMLElement; doc: Document; win: Window; isImg: boolean; area: number }[] = [];
    for (const d of collectDocs()) {
      const win = (d.defaultView || window) as Window;
      const vw = win.innerWidth || 1280, vh = win.innerHeight || 800;
      let els: NodeListOf<HTMLElement>; try { els = d.querySelectorAll<HTMLElement>("*"); } catch { continue; }
      els.forEach((el) => {
        if (el.classList.contains(FRAME_CLASS)) return;
        const isImg = el.tagName === "IMG";
        let hasBg = false; try { hasBg = ((win as any).getComputedStyle(el).backgroundImage || "").includes("url("); } catch {}
        if (!isImg && !hasBg) return;
        const r = el.getBoundingClientRect();
        if (r.width < vw * 0.55 || r.height < vh * 0.5) return;
        out.push({ el, doc: d, win, isImg, area: r.width * r.height });
      });
    }
    out.sort((a, b) => b.area - a.area);
    return out;
  }

  private tick() {
    if (!this.running) return;
    this.mounts = this.mounts.filter((m) => { if (m.frame.isConnected && m.el.isConnected) return true; try { m.frame.remove(); } catch {} return false; });

    const shouldPause = this.pauseInGame && gameRunning();
    if (shouldPause !== this.paused) {
      this.paused = shouldPause;
      for (const m of this.mounts) { try { m.frame.src = shouldPause ? "about:blank" : this.src(); } catch {} }
    }
    if (shouldPause) return;

    if (this.url) {
      for (const c of this.candidates()) {
        if (this.mounts.length >= MAX_MOUNTS) break;
        if (this.mounts.some((m) => m.el === c.el)) continue;
        this.mountOne(c);
      }
    }
    if (this.mounts.length && this.diagTimer) {
      const w: any = (typeof window !== "undefined" ? window : globalThis);
      (w.clearTimeout || clearTimeout)(this.diagTimer); this.diagTimer = 0;
      try { for (const d of collectDocs()) d.getElementById("floor796-diag")?.remove(); } catch {}
    }
    if (this.mounts.length && !this.pilled) { this.pilled = true; const m = this.mounts[0]; this.showPill(m.doc, m.win, "🪐 Floor796 active"); }
  }

  private mountOne(c: { el: HTMLElement; doc: Document; win: Window; isImg: boolean }) {
    const { el, doc, win, isImg } = c;
    try {
      this.ensureStyle(doc);
      let cs: any; try { cs = (win as any).getComputedStyle(el); } catch {}
      const frame = doc.createElement("iframe") as HTMLIFrameElement;
      frame.className = FRAME_CLASS;
      frame.setAttribute("scrolling", "no");
      frame.setAttribute("frameborder", "0");
      frame.style.opacity = String(this.opacity);
      let prevOpacity = "";

      if (isImg) {
        const parent = el.parentElement; if (!parent) return;
        let pcs: any; try { pcs = (win as any).getComputedStyle(parent); } catch {}
        if (pcs && pcs.position === "static") parent.classList.add(REL_CLASS);
        frame.style.left = el.offsetLeft + "px"; frame.style.top = el.offsetTop + "px";
        frame.style.width = el.offsetWidth + "px"; frame.style.height = el.offsetHeight + "px";
        el.insertAdjacentElement("afterend", frame);
        prevOpacity = el.style.opacity; el.style.opacity = "0";
      } else {
        if (cs && cs.position === "static") el.classList.add(REL_CLASS);
        el.appendChild(frame);
      }
      frame.src = this.src();

      this.mounts.push({ el, frame, isImg, prevOpacity, doc, win });
      console.log(`${LOG} mounted (${isImg ? "img" : "bg"}) layer`, el);
    } catch (e) { console.error(`${LOG} mountOne failed`, e); }
  }

  private showDiag() {
    try {
      const docs = collectDocs(); let vd: Document = document;
      try { const mw: any = (Router as any)?.WindowStore?.GamepadUIMainWindowInstance?.BrowserWindow; if (mw?.document) vd = mw.document; } catch {}
      const rep: string[] = [];
      for (const d of docs) {
        try {
          const w: any = d.defaultView || window; const vw = w.innerWidth || 1280, vh = w.innerHeight || 800;
          d.querySelectorAll<HTMLElement>("*").forEach((el) => {
            let cs: any; try { cs = w.getComputedStyle(el); } catch { return; }
            const bg = (cs.backgroundImage || "").includes("url("); if (!bg && el.tagName !== "IMG") return;
            const r = el.getBoundingClientRect(); if (r.width < vw * 0.4 || r.height < vh * 0.3) return;
            rep.push(`${el.tagName} ${Math.round(r.width)}x${Math.round(r.height)} ${bg ? "bg" : "img"}`);
          });
        } catch {}
      }
      const uniq = [...new Set(rep)].slice(0, 8);
      const id = "floor796-diag"; vd.getElementById(id)?.remove();
      const el = vd.createElement("div"); el.id = id;
      el.textContent = "Floor796: 0 layers mounted. url=" + (this.url ? "set" : "(waiting for server)") + " docs=" + docs.length + "\\n" + (uniq.length ? uniq.join("\\n") : "(no art elements)") + "\\n-> photo this";
      el.style.cssText = "position:fixed;top:8px;left:8px;z-index:2147483647;pointer-events:none;white-space:pre;font:12px/1.3 monospace;color:#cfd8e3;background:rgba(0,0,0,0.85);padding:8px 10px;border:1px solid #cfd8e3;border-radius:6px;";
      vd.body.appendChild(el);
    } catch {}
  }

  private showPill(d: Document, win: Window, text: string) {
    try {
      const id = "floor796-pill"; d.getElementById(id)?.remove();
      const el = d.createElement("div"); el.id = id; el.textContent = text;
      el.style.cssText = "position:fixed;top:10px;left:50%;transform:translateX(-50%);z-index:2147483647;pointer-events:none;font:14px monospace;color:#cfd8e3;background:rgba(0,0,0,0.8);padding:6px 12px;border:1px solid #cfd8e3;border-radius:14px;opacity:1;transition:opacity 1s ease 6s;";
      d.body.appendChild(el);
      const w: any = win; (w.setTimeout || setTimeout)(() => { el.style.opacity = "0"; }, 100); (w.setTimeout || setTimeout)(() => { el.remove(); }, 8000);
    } catch {}
  }
}
