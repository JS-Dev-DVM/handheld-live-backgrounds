import { definePlugin, call } from "@decky/api";
import { PanelSection, PanelSectionRow, ToggleField, SliderField, ButtonItem, Field } from "@decky/ui";
import { useEffect, useState } from "react";
import { FaCity } from "react-icons/fa";

import { Floor796Injector } from "./injector";

const LOG = "[Floor796]";

interface Settings { enabled: boolean; pauseInGame: boolean; opacity: number; }
const KEY = "floor796-bg.settings.v1";
const DEFAULTS: Settings = { enabled: true, pauseInGame: true, opacity: 100 };

function load(): Settings {
  try { const raw = localStorage.getItem(KEY); if (raw) return { ...DEFAULTS, ...JSON.parse(raw) }; } catch { /* */ }
  return { ...DEFAULTS };
}
function save(s: Settings) { try { localStorage.setItem(KEY, JSON.stringify(s)); } catch { /* */ } }

interface Status { ready: boolean; found: boolean; path: string; size: number; port: number; url: string; dataDir: string; }

let settings = load();
let injector: Floor796Injector;
try {
  injector = new Floor796Injector("", settings.pauseInGame, settings.opacity / 100);
  if (settings.enabled) injector.start();
} catch (e) {
  console.error(LOG, "init failed", e);
  injector = injector! ?? new Floor796Injector("", settings.pauseInGame, settings.opacity / 100);
}

async function fetchStatus(): Promise<Status | null> {
  try {
    const s = await call<[], Status>("get_status");
    if (s && s.url) injector.setUrl(s.url);
    return s;
  } catch (e) { console.error(LOG, "get_status failed", e); return null; }
}
// pull the server url as soon as the backend is up
fetchStatus();

function apply(next: Partial<Settings>) {
  settings = { ...settings, ...next };
  save(settings);
  try {
    injector.setPauseInGame(settings.pauseInGame);
    injector.setOpacity(settings.opacity / 100);
    if (settings.enabled) injector.start(); else injector.stop();
  } catch (e) { console.error(LOG, "apply failed", e); }
}

function mb(bytes: number): string { return bytes > 0 ? (bytes / (1024 * 1024)).toFixed(0) + " MB" : ""; }

function Content() {
  const [s, setS] = useState<Settings>(settings);
  const [st, setSt] = useState<Status | null>(null);
  const update = (p: Partial<Settings>) => { apply(p); setS({ ...settings }); };

  useEffect(() => {
    let alive = true;
    const pull = async () => { const x = await fetchStatus(); if (alive) setSt(x); };
    pull();
    const id = setInterval(pull, 3000);
    return () => { alive = false; clearInterval(id); };
  }, []);

  const statusLine = !st
    ? "Starting local server…"
    : !st.ready
      ? "Server not ready yet…"
      : st.found
        ? `File found ✓  (${mb(st.size)})`
        : "File NOT found — copy floor796.html to the folder below";

  return (
    <PanelSection title="Floor796 Wallpaper">
      <PanelSectionRow>
        <Field label="Status" focusable={true}>{statusLine}</Field>
      </PanelSectionRow>
      {st && !st.found && (
        <PanelSectionRow>
          <Field label="Put floor796.html here" focusable={true} description={st.dataDir || "(detecting…)"} />
        </PanelSectionRow>
      )}
      <PanelSectionRow>
        <ToggleField label="Enabled" checked={s.enabled} onChange={(v) => update({ enabled: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Opacity" value={s.opacity} min={20} max={100} step={5}
          description="How strong the wallpaper shows over the Steam background"
          onChange={(v) => update({ opacity: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <ToggleField label="Pause while playing" checked={s.pauseInGame}
          description="Saves battery: unloads the wallpaper while a game is running"
          onChange={(v) => update({ pauseInGame: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <ButtonItem layout="below" onClick={() => { try { injector.reload(); } catch (e) { console.error(LOG, e); } fetchStatus().then(setSt); }}>
          Reload wallpaper
        </ButtonItem>
      </PanelSectionRow>
    </PanelSection>
  );
}

export default definePlugin(() => ({
  name: "Floor796 Wallpaper",
  titleView: <div>Floor796 Wallpaper</div>,
  alwaysRender: false,
  content: <Content />,
  icon: <FaCity />,
  onDismount() {
    try { injector.stop(); } catch (e) { console.error(LOG, "onDismount failed", e); }
  },
}));
