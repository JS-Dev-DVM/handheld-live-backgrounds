import deckyPlugin from "@decky/rollup";

// The Decky rollup preset handles externals (react -> SP_REACT, @decky/ui,
// @decky/api) and emits dist/index.js in the format Decky Loader expects.
export default deckyPlugin({});
