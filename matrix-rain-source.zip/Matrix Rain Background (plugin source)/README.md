# Matrix Rain Background — Decky plugin (v3.0.0)

A live, infinite Matrix digital-rain animation drawn on the Steam Deck /
Big Picture **Home** background, behind your games. Everything is tunable from the
Quick Access Menu and your settings are saved between sessions.

## Install (Decky Developer Mode)
1. Copy `Matrix Rain Background.zip` to the Deck (Desktop Mode, e.g. ~/Downloads).
2. QAM (•••) → Decky (plug) → gear/Settings → enable **Developer Mode**.
3. Developer → **Install Plugin from ZIP File** → pick the zip.
4. QAM → Decky → **Matrix Rain Background** → make sure **Enabled** is on, go to Home.
5. Don't run the CSS "Matrix Code Rain" theme at the same time — they use the same
   spot and cancel out.

## Controls (Quick Access Menu)
- **Preset** — Preset 1, White, Glow Blue, or Custom (auto-selected when you tweak)
- **Speed**, **Density**, **Glyph size**
- **Trail length** — longer = streams run further (clean hard cutoff, no residue)
- **Glow**, **Bloom** — radiance on the head (GPU-heavy; lower if Home lags)
- **Flicker** — head shimmer; **Morph** — trail characters cycle as they fall
- **Color (hue)** — recolor the whole rain
- **Mirror katakana** — flip katakana (Matrix style)
- **White theme** — black glyphs on white (glow/bloom auto-off for a clean look)
- **Neon-green UI** — optional: recolor the Steam menus green

Built with @decky/api + @decky/ui (rollup). Frontend-only.
