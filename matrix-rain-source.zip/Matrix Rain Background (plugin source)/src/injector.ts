// injector.ts — multi-layer, name-independent.
// Modern Steam obfuscates classnames AND stacks several full-screen art layers
// (wallpaper, blurred hero, etc.). We paint an opaque rain canvas over EVERY
// full-screen art layer we can find — both <img> heroes and background-image
// heroes — across every Steam document. Whichever layer is actually visible gets
// the rain. Card/text art is below the size threshold, so it's never covered.

import { findSP, getGamepadNavigationTrees, Router } from "@decky/ui";
import { MatrixRain, MatrixConfig } from "./matrixRain";

const CANVAS_CLASS = "matrix-rain-canvas";
const REL_CLASS = "matrix-rain-rel";
const STYLE_ID = "matrix-rain-style";
const UI_STYLE_ID = "matrix-rain-ui-green";
const LOG = "[MatrixRain]";
const NEON = "#39FF14";

const UI_GREEN_CSS = `
[class*="gamepad"], [class*="gamepad"] * { color:${NEON} !important; text-shadow:0 0 3px rgba(57,255,20,0.45) !important; border-color:rgba(57,255,20,0.30) !important; }
svg, svg * { fill:${NEON} !important; }
img { text-shadow:none !important; }`;

const HOST_CSS = `
.${REL_CLASS} { position: relative !important; }
.${CANVAS_CLASS} { position:absolute !important; z-index:2147483646 !important; pointer-events:none !important; display:block !important; }`;

function collectDocs(): Document[] {
  const set = new Set<Document>();
  const add = (d?: Document | null) => { if (d && d.body) set.add(d); };
  try { add(document); } catch {}
  try { add(findSP()?.document); } catch {}
  try { const t = getGamepadNavigationTrees?.(); if (Array.isArray(t)) for (const x of t) { try { add(x?.Root?.Element?.ownerDocument); } catch {} } } catch {}
  try {
    const ws: any = (Router as any)?.WindowStore; const rs: any[] = [];
    if (ws) { if (ws.GamepadUIMainWindowInstance) rs.push(ws.GamepadUIMainWindowInstance); if (Array.isArray(ws.SteamUIWindows)) rs.push(...ws.SteamUIWindows); if (Array.isArray(ws.OverlayWindows)) rs.push(...ws.OverlayWindows); }
    for (const r of rs) { try { add(r?.BrowserWindow?.document); } catch {} }
  } catch {}
  try { add((window as any).SteamUIStore?.GetFocusedWindowInstance?.()?.BrowserWindow?.document); } catch {}
  for (const d of [...set]) { try { d.querySelectorAll("iframe").forEach((f) => { try { add((f as HTMLIFrameElement).contentDocument); } catch {} }); } catch {} }
  return [...set];
}

interface Mount { el: HTMLElement; cv: HTMLCanvasElement; rain: MatrixRain; ro?: ResizeObserver; isImg: boolean; prevOpacity: string; win: Window; doc: Document; }

export class RainInjector {
  private mounts: Mount[] = [];
  private timer = 0;
  private diagTimer = 0;
  private running = false;
  private styledDocs = new WeakSet<Document>();
  private uiStyledDocs: Document[] = [];
  private warned = false;
  private pilled = false;
  private pauseInGame = true;
  private pausedForGame = false;

  constructor(private cfg: MatrixConfig) {}
  setConfig(p: Partial<MatrixConfig>) { Object.assign(this.cfg, p); for (const m of this.mounts) m.rain.setConfig(p); }
  setPauseInGame(on: boolean) { this.pauseInGame = on; }

  start() {
    if (this.running) return;
    this.running = true;
    this.tick();
    const w: any = (typeof window !== "undefined" ? window : globalThis);
    this.timer = (w.setInterval || setInterval)(() => this.tick(), 800);
    this.diagTimer = (w.setTimeout || setTimeout)(() => { if (!this.mounts.length) this.showDiag(); }, 4500);
    console.log(`${LOG} started`);
  }

  stop() {
    this.running = false;
    const w: any = (typeof window !== "undefined" ? window : globalThis);
    if (this.timer) { (w.clearInterval || clearInterval)(this.timer); this.timer = 0; }
    if (this.diagTimer) { (w.clearTimeout || clearTimeout)(this.diagTimer); this.diagTimer = 0; }
    for (const m of this.mounts) {
      try { m.ro?.disconnect(); } catch {}
      try { m.rain.stop(); } catch {}
      try { m.cv.remove(); } catch {}
      try { if (m.isImg) m.el.style.opacity = m.prevOpacity; m.el.classList.remove(REL_CLASS); } catch {}
      try { m.doc.getElementById("matrix-rain-pill")?.remove(); m.doc.getElementById("matrix-rain-diag")?.remove(); } catch {}
    }
    this.mounts = []; this.pilled = false;
    console.log(`${LOG} stopped`);
  }

  setGreenUI(on: boolean) {
    if (on) {
      for (const d of collectDocs()) { if (d.getElementById(UI_STYLE_ID)) continue; try { const s = d.createElement("style"); s.id = UI_STYLE_ID; s.textContent = UI_GREEN_CSS; d.head.appendChild(s); this.uiStyledDocs.push(d); } catch {} }
    } else { for (const d of this.uiStyledDocs) { try { d.getElementById(UI_STYLE_ID)?.remove(); } catch {} } this.uiStyledDocs = []; }
  }

  private ensureStyle(d: Document) { if (this.styledDocs.has(d) || d.getElementById(STYLE_ID)) { this.styledDocs.add(d); return; } const s = d.createElement("style"); s.id = STYLE_ID; s.textContent = HOST_CSS; d.head.appendChild(s); this.styledDocs.add(d); }

  private candidates(): { el: HTMLElement; doc: Document; win: Window; isImg: boolean; area: number }[] {
    const out: { el: HTMLElement; doc: Document; win: Window; isImg: boolean; area: number }[] = [];
    for (const d of collectDocs()) {
      const win = (d.defaultView || window) as Window;
      const vw = win.innerWidth || 1280, vh = win.innerHeight || 800;
      let els: NodeListOf<HTMLElement>; try { els = d.querySelectorAll<HTMLElement>("*"); } catch { continue; }
      els.forEach((el) => {
        if (el.classList.contains(CANVAS_CLASS)) return;
        const isImg = el.tagName === "IMG";
        let hasBg = false; try { hasBg = ((win as any).getComputedStyle(el).backgroundImage || "").includes("url("); } catch {}
        if (!isImg && !hasBg) return;
        const r = el.getBoundingClientRect();
        if (r.width < vw * 0.55 || r.height < vh * 0.5) return;
        out.push({ el, doc: d, win, isImg, area: r.width * r.height });
      });
    }
    return out;
  }

  private tick() {
    if (!this.running) return;
    // drop dead mounts
    this.mounts = this.mounts.filter((m) => { if (m.cv.isConnected && m.el.isConnected) return true; try { m.ro?.disconnect(); m.rain.stop(); m.cv.remove(); } catch {} return false; });

    const cands = this.candidates().sort((a, b) => b.area - a.area).slice(0, 2);
    for (const c of cands) {
      if (this.mounts.some((m) => m.el === c.el)) continue;
      this.mountOne(c);
    }
    if (this.mounts.length && this.diagTimer) {
      const w: any = (typeof window !== "undefined" ? window : globalThis);
      (w.clearTimeout || clearTimeout)(this.diagTimer); this.diagTimer = 0;
      try { for (const d of collectDocs()) d.getElementById("matrix-rain-diag")?.remove(); } catch {}
    }
    if (this.mounts.length && !this.pilled) { this.pilled = true; const m = this.mounts[0]; this.showPill(m.doc, m.win, `▸ Matrix Rain active (${this.mounts.length} layer${this.mounts.length > 1 ? "s" : ""})`); }

    // Auto-pause the animation while a game is running (saves GPU/battery — the
    // Home canvas isn't visible behind a running game anyway).
    let running = false;
    try { running = !!(Router as any)?.MainRunningApp; } catch {}
    if (this.pauseInGame && running) {
      if (!this.pausedForGame) { this.pausedForGame = true; for (const m of this.mounts) { try { m.rain.stop(); } catch {} } }
    } else if (this.pausedForGame) {
      this.pausedForGame = false; for (const m of this.mounts) { try { m.rain.start(); } catch {} }
    }
  }

  private mountOne(c: { el: HTMLElement; doc: Document; win: Window; isImg: boolean }) {
    const { el, doc, win, isImg } = c;
    try {
      this.ensureStyle(doc);
      let cs: any; try { cs = (win as any).getComputedStyle(el); } catch {}
      const cv = doc.createElement("canvas"); cv.className = CANVAS_CLASS;
      let prevOpacity = "";

      if (isImg) {
        const parent = el.parentElement; if (!parent) return;
        let pcs: any; try { pcs = (win as any).getComputedStyle(parent); } catch {}
        if (pcs && pcs.position === "static") parent.classList.add(REL_CLASS);
        // cover exactly the image's box
        cv.style.left = el.offsetLeft + "px"; cv.style.top = el.offsetTop + "px";
        cv.style.width = el.offsetWidth + "px"; cv.style.height = el.offsetHeight + "px";
        el.insertAdjacentElement("afterend", cv);
        prevOpacity = el.style.opacity; el.style.opacity = "0"; // hide original art
      } else {
        if (cs && cs.position === "static") el.classList.add(REL_CLASS);
        cv.style.inset = "0"; cv.style.width = "100%"; cv.style.height = "100%";
        el.appendChild(cv); // last child → above the background-image
      }

      const rain = new MatrixRain(cv, this.cfg, win);
      const raf: any = (win as any).requestAnimationFrame ? (win as any).requestAnimationFrame.bind(win) : requestAnimationFrame;
      raf(() => { try { rain.resize(); rain.start(); } catch (e) { console.error(`${LOG} rain start failed`, e); } });
      let ro: ResizeObserver | undefined;
      try { const RO: any = (win as any).ResizeObserver || ResizeObserver; ro = new RO(() => rain.resize()); ro!.observe(isImg ? (el.parentElement || el) : el); } catch {}

      this.mounts.push({ el, cv, rain, ro, isImg, prevOpacity, win, doc });
      console.log(`${LOG} mounted (${isImg ? "img" : "bg"}) layer`, el);
    } catch (e) { console.error(`${LOG} mountOne failed`, e); }
  }

  private showDiag() {
    try {
      const docs = collectDocs(); let vd: Document = document;
      try { const mw: any = (Router as any)?.WindowStore?.GamepadUIMainWindowInstance?.BrowserWindow; if (mw?.document) vd = mw.document; } catch {}
      const rep: string[] = [];
      for (const d of docs) {
        try {
          const w: any = d.defaultView || window; const vw = w.innerWidth || 1280, vh = w.innerHeight || 800;
          d.querySelectorAll<HTMLElement>("*").forEach((el) => {
            let cs: any; try { cs = w.getComputedStyle(el); } catch { return; }
            const bg = (cs.backgroundImage || "").includes("url("); if (!bg && el.tagName !== "IMG") return;
            const r = el.getBoundingClientRect(); if (r.width < vw * 0.4 || r.height < vh * 0.3) return;
            rep.push(`${el.tagName} ${Math.round(r.width)}x${Math.round(r.height)} ${bg ? "bg" : "img"}`);
          });
        } catch {}
      }
      const uniq = [...new Set(rep)].slice(0, 8);
      const id = "matrix-rain-diag"; vd.getElementById(id)?.remove();
      const el = vd.createElement("div"); el.id = id;
      el.textContent = "MatrixRain v2.5: 0 layers mounted. docs=" + docs.length + "\\n" + (uniq.length ? uniq.join("\\n") : "(no art elements)") + "\\n→ photo this";
      el.style.cssText = "position:fixed;top:8px;left:8px;z-index:2147483647;pointer-events:none;white-space:pre;font:12px/1.3 monospace;color:#39FF14;background:rgba(0,0,0,0.85);padding:8px 10px;border:1px solid #39FF14;border-radius:6px;";
      vd.body.appendChild(el);
    } catch {}
  }

  private showPill(d: Document, win: Window, text: string) {
    try {
      const id = "matrix-rain-pill"; d.getElementById(id)?.remove();
      const el = d.createElement("div"); el.id = id; el.textContent = text;
      el.style.cssText = "position:fixed;top:10px;left:50%;transform:translateX(-50%);z-index:2147483647;pointer-events:none;font:14px monospace;color:#39FF14;background:rgba(0,0,0,0.8);padding:6px 12px;border:1px solid #39FF14;border-radius:14px;opacity:1;transition:opacity 1s ease 6s;";
      d.body.appendChild(el);
      const w: any = win; (w.setTimeout || setTimeout)(() => { el.style.opacity = "0"; }, 100); (w.setTimeout || setTimeout)(() => { el.remove(); }, 8000);
    } catch {}
  }
}

export { CANVAS_CLASS };
