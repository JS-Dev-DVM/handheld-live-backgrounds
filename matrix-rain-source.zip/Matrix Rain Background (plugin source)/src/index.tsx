import { definePlugin } from "@decky/api";
import { PanelSection, PanelSectionRow, ToggleField, SliderField, DropdownItem } from "@decky/ui";
import { useState } from "react";
import { FaTerminal } from "react-icons/fa";

import { RainInjector } from "./injector";
import { DEFAULT_CONFIG, MatrixConfig } from "./matrixRain";

interface Settings {
  enabled: boolean;
  speed: number;     // 1..10
  density: number;   // 1..10
  fontSize: number;  // 10..34
  trail: number;     // 1..10  (trail length)
  glow: number;      // 0..24  (head glow)
  bloom: number;     // 0..24  (head bloom halo)
  flicker: number;   // 0..20  (head flicker %)
  morph: number;     // 0..20  (trail morph %)
  hue: number;       // 0..360 (color)
  mirror: boolean;
  whiteTheme: boolean;
  greenUI: boolean;
  fps: number;        // 30/45/60 max frames per second
  font: number;       // index into FONTS
  pauseInGame: boolean;
  preset: number; // index of active preset, -1 = Custom
}
const KEY = "matrix-rain-bg.settings.v6";
const FONTS: { name: string; css: string }[] = [
  { name: "Noto CJK (default)", css: "'Noto Sans CJK JP','Noto Sans Mono CJK JP',monospace" },
  { name: "Noto Mono CJK", css: "'Noto Sans Mono CJK JP',monospace" },
  { name: "Monospace", css: "monospace" },
  { name: "Sans-serif", css: "sans-serif" },
  { name: "Serif", css: "serif" },
  { name: "Courier", css: "'Courier New',Courier,monospace" },
];

type PresetSettings = Omit<Settings, "enabled" | "greenUI" | "fps" | "font" | "pauseInGame" | "preset">;
interface Preset { name: string; settings: PresetSettings; }
const PRESETS: Preset[] = [
  { name: "Preset 1",      settings: { speed: 5, density: 9,  fontSize: 20, trail: 8,  glow: 0,  bloom: 11, flicker: 8, morph: 0, hue: 135, mirror: true,  whiteTheme: false } },
  { name: "White",         settings: { speed: 6, density: 8,  fontSize: 21, trail: 4,  glow: 0,  bloom: 0,  flicker: 6, morph: 0, hue: 135, mirror: false, whiteTheme: true  } },
  { name: "Glow Blue",     settings: { speed: 6, density: 9,  fontSize: 20, trail: 8,  glow: 22, bloom: 20, flicker: 8, morph: 1, hue: 265, mirror: true,  whiteTheme: false } },
]

const DEFAULTS: Settings = {
  enabled: true, greenUI: false, fps: 30, font: 0, pauseInGame: true, preset: 0, ...PRESETS[0].settings,
};

function load(): Settings {
  try { const raw = localStorage.getItem(KEY); if (raw) return { ...DEFAULTS, ...JSON.parse(raw) }; } catch { /* */ }
  return { ...DEFAULTS };
}
function save(s: Settings) { try { localStorage.setItem(KEY, JSON.stringify(s)); } catch { /* */ } }

const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const hsl = (h: number, s: number, l: number) => `hsl(${h} ${s}% ${l}%)`;

function toConfig(s: Settings): MatrixConfig {
  const maxSpeed = lerp(8, 42, (s.speed - 1) / 9);
  const density = lerp(0.6, 2.6, (s.density - 1) / 9);
  const fadeAlpha = lerp(0.18, 0.06, (s.trail - 1) / 9); // higher trail -> longer
  const tailCells = Math.round(lerp(10, 34, (s.trail - 1) / 9));
  const base: MatrixConfig = {
    ...DEFAULT_CONFIG,
    fontSize: s.fontSize,
    density,
    minSpeed: maxSpeed * 0.4,
    maxSpeed,
    fadeAlpha,
    tailCells,
    headGlow: s.glow,
    bloomGlow: s.bloom,
    mutateChance: s.flicker / 100,
    morphChance: s.morph / 20,
    mirror: s.mirror,
    fps: s.fps,
    fontFamily: (FONTS[s.font] || FONTS[0]).css,
  };
  if (s.whiteTheme) {
    return { ...base, background: "#ffffff", headColor: "#000000", leadColor: "#000000", bodyColor: "#1a1a1a", bloomColor: "#555555", headGlow: 0, bloomGlow: 0 };
  }
  const h = s.hue;
  return {
    ...base,
    background: "#000000",
    headColor: hsl(h, 100, 88),
    leadColor: hsl(h, 100, 70),
    bloomColor: hsl(h, 100, 55),
    bodyColor: hsl(h, 100, 45),
  };
}

let settings = load();
let injector: RainInjector;
try {
  injector = new RainInjector(toConfig(settings));
  injector.setPauseInGame(settings.pauseInGame);
  if (settings.enabled) injector.start();
  injector.setGreenUI(settings.greenUI);
} catch (e) {
  console.error("[MatrixRain] init failed", e);
  injector = injector! ?? new RainInjector(toConfig(settings));
}

function apply(next: Partial<Settings>) {
  settings = { ...settings, ...next };
  save(settings);
  try {
    injector.setConfig(toConfig(settings));
    injector.setGreenUI(settings.greenUI);
    injector.setPauseInGame(settings.pauseInGame);
    if (settings.enabled) injector.start(); else injector.stop();
  } catch (e) { console.error("[MatrixRain] apply failed", e); }
}

function Content() {
  const [s, setS] = useState<Settings>(settings);
  const update = (p: Partial<Settings>) => { apply(p); setS({ ...settings }); };
  // manual slider/toggle change -> mark as Custom
  const tweak = (p: Partial<Settings>) => update({ ...p, preset: -1 });
  const applyPreset = (i: number) => update({ ...PRESETS[i].settings, preset: i });

  return (
    <PanelSection title="Matrix Rain Background">
      <PanelSectionRow>
        <ToggleField label="Enabled" checked={s.enabled} onChange={(v) => update({ enabled: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <DropdownItem
          label="Preset"
          rgOptions={[
            ...PRESETS.map((p, i) => ({ data: i, label: p.name })),
            { data: -1, label: "Custom" },
          ]}
          selectedOption={s.preset}
          onChange={(o) => { if (o.data === -1) update({ preset: -1 }); else applyPreset(o.data as number); }}
        />
      </PanelSectionRow>

      <PanelSectionRow>
        <SliderField label="Speed" value={s.speed} min={1} max={10} step={1} notchTicksVisible
          onChange={(v) => tweak({ speed: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Density" value={s.density} min={1} max={10} step={1} notchTicksVisible
          onChange={(v) => tweak({ density: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Glyph size" value={s.fontSize} min={10} max={34} step={1}
          onChange={(v) => tweak({ fontSize: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Trail length" value={s.trail} min={1} max={10} step={1} notchTicksVisible
          onChange={(v) => tweak({ trail: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Glow" value={s.glow} min={0} max={24} step={1}
          onChange={(v) => tweak({ glow: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Bloom" value={s.bloom} min={0} max={24} step={1}
          onChange={(v) => tweak({ bloom: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Flicker" value={s.flicker} min={0} max={20} step={1}
          onChange={(v) => tweak({ flicker: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Morph" value={s.morph} min={0} max={20} step={1}
          onChange={(v) => tweak({ morph: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Color (hue)" value={s.hue} min={0} max={360} step={5}
          description="Ignored while White theme is on"
          onChange={(v) => tweak({ hue: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField label="Max FPS" value={s.fps} min={30} max={60} step={15}
          description="Lower = less GPU / battery"
          onChange={(v) => update({ fps: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <DropdownItem
          label="Font"
          rgOptions={FONTS.map((f, i) => ({ data: i, label: f.name }))}
          selectedOption={s.font}
          onChange={(o) => update({ font: o.data as number })}
        />
      </PanelSectionRow>

      <PanelSectionRow>
        <ToggleField label="Mirror katakana" description="Flip katakana (Matrix style)"
          checked={s.mirror} onChange={(v) => tweak({ mirror: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <ToggleField label="White theme" description="Black glyphs on a white background"
          checked={s.whiteTheme} onChange={(v) => tweak({ whiteTheme: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <ToggleField label="Pause in game" description="Stop the animation while a game is running"
          checked={s.pauseInGame} onChange={(v) => update({ pauseInGame: v })} />
      </PanelSectionRow>
      <PanelSectionRow>
        <ToggleField label="Neon-green UI" description="Recolor menu text & icons green"
          checked={s.greenUI} onChange={(v) => update({ greenUI: v })} />
      </PanelSectionRow>
    </PanelSection>
  );
}

export default definePlugin(() => ({
  name: "Matrix Rain Background",
  titleView: <div>Matrix Rain Background</div>,
  alwaysRender: false,
  content: <Content />,
  icon: <FaTerminal />,
  onDismount() {
    try { injector.stop(); injector.setGreenUI(false); } catch (e) { console.error("[MatrixRain] onDismount failed", e); }
  },
}));
