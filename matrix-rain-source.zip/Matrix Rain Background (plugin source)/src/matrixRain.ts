// matrixRain.ts — framework-free canvas engine with tweakable parameters.
// All visual knobs (colors, glow, bloom, flicker, morph, mirror, trail length)
// are config-driven so the QAM sliders can change them live. Performance note:
// only the HEAD is ever blurred (glow/bloom); trails and lead glyphs are crisp.

export interface MatrixConfig {
  fontSize: number;
  background: string;     // hex (#000000 / #ffffff) — used for the fade overlay
  fadeAlpha: number;      // lower = longer trails
  density: number;        // streams per column
  minSpeed: number;
  maxSpeed: number;
  mutateChance: number;   // 0..1 head flicker in place
  morphChance: number;    // 0..1 trail glyph cycling (0 = off)
  trailLen: number;       // how far back morph reaches
  tailCells: number;      // hard-clear glyphs older than this many rows (kills residue)
  headGlow: number;       // px blur on the head core (0 = crisp)
  bloomGlow: number;      // px blur for an extra additive head halo (0 = off)
  headColor: string;
  leadColor: string;      // bright glyph just behind the head
  bloomColor: string;
  bodyColor: string;
  mirror: boolean;        // mirror half-width katakana
  fps: number;            // target max frames per second (perf)
  fontFamily: string;     // CSS font family for glyphs
  glyphs: string;
}

export const DEFAULT_GLYPHS =
  "ｦｧｨｩｪｫｬｭｮｯｰｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜﾝ" +
  "0123456789ABCDEFGHJKLMNPQRSTUVWXYZ";

export const DEFAULT_CONFIG: MatrixConfig = {
  fontSize: 18, background: "#000000", fadeAlpha: 0.07, density: 1.6,
  minSpeed: 7, maxSpeed: 20, mutateChance: 0.05, morphChance: 0, trailLen: 16, tailCells: 24,
  headGlow: 10, bloomGlow: 0,
  headColor: "#caffca", leadColor: "#7dff7d", bloomColor: "#39ff14", bodyColor: "#00ff41",
  mirror: false, fps: 60, fontFamily: "'Noto Sans CJK JP','Noto Sans Mono CJK JP',monospace",
  glyphs: DEFAULT_GLYPHS,
};

interface Drop { col: number; y: number; speed: number; lastRow: number; prev: string; }

export class MatrixRain {
  private ctx: CanvasRenderingContext2D;
  private cfg: MatrixConfig;
  private drops: Drop[] = [];
  private cols = 0; private rows = 0; private cssW = 0; private cssH = 0;
  private raf = 0; private last = 0;
  private bg = { r: 0, g: 0, b: 0 };
  private win: Window = (typeof window !== "undefined" ? window : (globalThis as any));

  constructor(private canvas: HTMLCanvasElement, cfg: MatrixConfig, win?: Window) {
    this.cfg = { ...cfg };
    if (win) this.win = win;
    const c = canvas.getContext("2d", { alpha: false });
    if (!c) throw new Error("2d context unavailable");
    this.ctx = c;
    this.bg = MatrixRain.hexToRgb(this.cfg.background);
  }

  setConfig(p: Partial<MatrixConfig>) {
    Object.assign(this.cfg, p);
    this.bg = MatrixRain.hexToRgb(this.cfg.background);
    if (p.fontSize !== undefined || p.density !== undefined || p.background !== undefined) {
      this.resize();
    } else if ((p.headGlow !== undefined || p.bloomGlow !== undefined) && this.cssW > 0) {
      // wipe lingering glow instantly so glow/bloom changes take effect at once
      this.ctx.fillStyle = this.cfg.background;
      this.ctx.fillRect(0, 0, this.cssW, this.cssH);
    }
  }

  resize() {
    const rect = this.canvas.getBoundingClientRect();
    this.cssW = Math.max(1, rect.width || this.canvas.clientWidth || 1280);
    this.cssH = Math.max(1, rect.height || this.canvas.clientHeight || 800);
    const dpr = Math.min(this.win.devicePixelRatio || 1, 2);
    this.canvas.width = Math.floor(this.cssW * dpr);
    this.canvas.height = Math.floor(this.cssH * dpr);
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    this.cols = Math.max(1, Math.floor(this.cssW / this.cfg.fontSize));
    this.rows = Math.max(1, Math.floor(this.cssH / this.cfg.fontSize) + 1);
    this.ctx.textAlign = "center";
    this.ctx.textBaseline = "middle";
    this.ctx.fillStyle = this.cfg.background;
    this.ctx.fillRect(0, 0, this.cssW, this.cssH);
    const n = Math.max(1, Math.floor(this.cols * this.cfg.density));
    this.drops = [];
    for (let i = 0; i < n; i++) this.drops.push(this.spawn(true));
  }

  private spawn(initial = false): Drop {
    const col = (Math.random() * this.cols) | 0;
    const y = initial ? Math.random() * this.rows : -Math.random() * this.rows * 0.6 - 1;
    const speed = this.cfg.minSpeed + Math.random() * (this.cfg.maxSpeed - this.cfg.minSpeed);
    return { col, y, speed, lastRow: Math.floor(y), prev: this.rand() };
  }

  private rand(): string {
    const g = this.cfg.glyphs;
    return g.charAt((Math.random() * g.length) | 0);
  }

  private static isKatakana(ch: string): boolean {
    const c = ch.charCodeAt(0);
    return (c >= 0xff66 && c <= 0xff9d) || (c >= 0x30a0 && c <= 0x30ff);
  }

  private glyph(col: number, row: number, ch: string, color: string, glow: number) {
    const fs = this.cfg.fontSize;
    const x = col * fs + fs / 2;
    const y = row * fs + fs / 2;
    const ctx = this.ctx;
    if (glow > 0) { ctx.shadowBlur = glow; ctx.shadowColor = color; }
    ctx.fillStyle = color;
    if (this.cfg.mirror && MatrixRain.isKatakana(ch)) {
      ctx.save(); ctx.translate(x, y); ctx.scale(-1, 1); ctx.fillText(ch, 0, 0); ctx.restore();
    } else {
      ctx.fillText(ch, x, y);
    }
    if (glow > 0) ctx.shadowBlur = 0;
  }

  private clearCell(col: number, row: number) {
    const fs = this.cfg.fontSize;
    this.ctx.fillStyle = this.cfg.background;
    this.ctx.fillRect(col * fs - 1, row * fs - 1, fs + 2, fs + 2);
  }

  private head(col: number, row: number, ch: string) {
    if (this.cfg.bloomGlow > 0) this.glyph(col, row, ch, this.cfg.bloomColor, this.cfg.bloomGlow);
    this.glyph(col, row, ch, this.cfg.headColor, this.cfg.headGlow);
  }

  start() {
    if (this.raf) return;
    const w: any = this.win;
    const raf: (cb: FrameRequestCallback) => number =
      (w.requestAnimationFrame ? w.requestAnimationFrame.bind(w) : requestAnimationFrame);
    const now = () => (w.performance && w.performance.now ? w.performance.now() : Date.now());
    let lastDraw = now();
    const loop = (t: number) => {
      this.raf = raf(loop);
      const minDt = 1000 / Math.max(1, this.cfg.fps || 60);
      const elapsed = t - lastDraw;
      if (elapsed < minDt - 0.5) return; // throttle to target FPS
      lastDraw = t;
      this.step(Math.min(0.05, elapsed / 1000));
    };
    this.raf = raf(loop);
  }

  stop() {
    const w: any = this.win;
    const caf: (h: number) => void =
      (w.cancelAnimationFrame ? w.cancelAnimationFrame.bind(w) : cancelAnimationFrame);
    if (this.raf) caf(this.raf);
    this.raf = 0;
  }

  private step(dt: number) {
    const { fontSize, fadeAlpha, bodyColor, leadColor, mutateChance, morphChance, trailLen } = this.cfg;
    this.ctx.fillStyle = `rgba(${this.bg.r},${this.bg.g},${this.bg.b},${fadeAlpha})`;
    this.ctx.fillRect(0, 0, this.cssW, this.cssH);
    this.ctx.font = `${fontSize}px ${this.cfg.fontFamily}`;

    for (const d of this.drops) {
      d.y += d.speed * dt;
      const r = Math.floor(d.y);
      if (r > d.lastRow) {
        if (d.lastRow >= 0 && d.lastRow < this.rows) this.glyph(d.col, d.lastRow, d.prev, leadColor, 0);
        for (let rr = d.lastRow + 1; rr < r; rr++) {
          if (rr >= 0 && rr < this.rows) this.glyph(d.col, rr, this.rand(), bodyColor, 0);
        }
        const g = this.rand();
        d.prev = g;
        if (r >= 0 && r < this.rows) this.head(d.col, r, g);
        // hard-clear cells older than the tail so no faint residue lingers
        for (let rr = d.lastRow + 1; rr <= r; rr++) {
          const old = rr - this.cfg.tailCells;
          if (old >= 0 && old < this.rows) this.clearCell(d.col, old);
        }
        d.lastRow = r;
        if (r > this.rows + 1) Object.assign(d, this.spawn(false));
      } else if (Math.random() < mutateChance && r >= 0 && r < this.rows) {
        const g = this.rand();
        d.prev = g;
        this.head(d.col, r, g);
      }
      if (morphChance > 0 && Math.random() < morphChance) {
        const rr = d.lastRow - (1 + ((Math.random() * trailLen) | 0));
        if (rr >= 0 && rr < this.rows) this.glyph(d.col, rr, this.rand(), bodyColor, 0);
      }
    }
  }

  private static hexToRgb(hex: string) {
    const m = /^#?([0-9a-f]{6})$/i.exec(hex.trim());
    if (!m) return { r: 0, g: 0, b: 0 };
    const n = parseInt(m[1], 16);
    return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
  }
}
